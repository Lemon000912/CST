/**
 * 规格 2.1：意图解析与重写。
 * 调用任意 OpenAI 兼容的 Chat Completions（POST …/chat/completions）。
 * 接口地址优先级：调用方 opts.chatCompletionsUrl → LLM_CHAT_COMPLETIONS_URL → 默认 DeepSeek 官方兼容端点。
 * 密钥优先级：调用方 apiKey → LLM_API_KEY → OPENAI_API_KEY → DASHSCOPE_API_KEY。
 * （不再读取 DEEPSEEK_API_KEY；旧部署请改名为 LLM_API_KEY。）
 * @param {string} userQuery
 * @param {{ apiKey?: string; model?: string; chatCompletionsUrl?: string }} [opts]
 */

const DEFAULT_DEEPSEEK_CHAT = "https://api.deepseek.com/v1/chat/completions";

/** @param {string} s */
export function safeHttpUrl(s) {
  const u = String(s ?? "").trim();
  if (!u || u.length > 2048) return "";
  try {
    const parsed = new URL(u);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return "";
    return parsed.toString();
  } catch {
    return "";
  }
}

export function resolveChatCompletionsUrl(fromClient) {
  const client = safeHttpUrl(fromClient);
  if (client) return client;
  const env = safeHttpUrl(process.env.LLM_CHAT_COMPLETIONS_URL);
  if (env) return env;
  return DEFAULT_DEEPSEEK_CHAT;
}

export function defaultModel() {
  const m = String(
    process.env.LLM_MODEL ??
      process.env.DEEPSEEK_MODEL ??
      process.env.DASHSCOPE_MODEL ??
      process.env.OPENAI_MODEL ??
      "",
  ).trim();
  return m || "deepseek-v4-flash";
}

/**
 * 验证并清理 model 名称
 * 防止 API Key 被错误地传入 model 字段
 */
export function sanitizeModel(model) {
  const m = String(model ?? "").trim();
  if (!m) return defaultModel();
  // 如果 model 以 sk- 开头（API Key 格式），使用默认模型
  if (m.startsWith("sk-")) return defaultModel();
  // 如果 model 过长（超过 64 字符），使用默认模型
  if (m.length > 64) return defaultModel();
  // 只允许合法的模型名称字符
  if (!/^[a-zA-Z0-9._-]+$/.test(m)) return defaultModel();
  return m;
}

export function resolveApiKey(fromClient) {
  // 优先使用环境变量中的 Key（服务器端配置更可靠）
  const envKey =
    String(process.env.LLM_API_KEY ?? "").trim() ||
    String(process.env.OPENAI_API_KEY ?? "").trim() ||
    String(process.env.DEEPSEEK_API_KEY ?? "").trim() ||
    String(process.env.DASHSCOPE_API_KEY ?? "").trim();
  if (envKey) return envKey;

  // 如果环境变量没有，才使用前端传来的 Key
  const c = String(fromClient ?? "").trim();
  return c;
}

/** 判为「解释用户意图」的废话行，不作为检索式 */
function isVerboseExplanationChunk(t) {
  const s = String(t ?? "").trim();
  if (!s) return true;
  if (s.length > 260) return true;
  const head = s.slice(0, 100).toLowerCase();
  if (
    /^(we need|the user |understand |this is a |this is an |the query |the research |the question |here is |here are |i will |let me |first,|note:|output:)/i.test(
      head,
    )
  )
    return true;
  // 过滤中文胡说八道（当LLM收到乱码输入时的无意义回复）
  if (/^[\u4e00-\u9fff]{2,}.*(?:输入|输出|认为|所以|因为|但是|然而|因此|鉴于|由于)/.test(s.slice(0, 80)))
    return true;
  if (/\bwhich means\b/i.test(s.slice(0, 160))) return true;
  if (/\bthe user (asks|wants|likely)\b/i.test(head)) return true;
  return false;
}

/**
 * 从 LLM 原文中抽出单行英文检索词：忽略开头的意图分析段落，优先短行/句末关键词行。
 * 特别处理包含思考过程的情况（如DeepSeek的reasoning_content）
 */
function normalizeKeywordLine(raw) {
  let s = String(raw ?? "").trim();
  if (!s) return "";

  // 移除代码块标记
  s = s.replace(/^```[a-zA-Z]*\s*/m, "").replace(/\s*```$/m, "").trim();

  // 移除首尾的引号（包括中文引号）
  s = s.replace(/^[\"'\"'\"'\"'\"'\"']+/, "").replace(/[\"'\"'\"'\"'\"'\"']+$/, "").trim();

  // 如果包含明显的思考过程标记，尝试提取最后的实际输出
  const thinkPatterns = [
    /(?:so|therefore|thus|output|answer|result)[:：]\s*([\s\S]*?)$/i,
    /(?:输出|答案|结果)[:：]\s*([\s\S]*?)$/i,
    /(?:最终|final)\s*(?:输出|output|结果|result)[:：]\s*([\s\S]*?)$/i,
  ];

  for (const pattern of thinkPatterns) {
    const match = s.match(pattern);
    if (match && match[1]) {
      const extracted = match[1].trim().split(/\n/)[0].trim().replace(/^[\"'\"'\"'\"'\"'\"']+/, "").replace(/[\"'\"'\"'\"'\"'\"']+$/, "").trim();
      if (extracted.length >= 5 && extracted.length <= 500 && !isVerboseExplanationChunk(extracted)) {
        return extracted.slice(0, 900);
      }
    }
  }

  // 尝试找到最后一行看起来像关键词的行
  const lines = s.split(/\r?\n/).map((x) => x.trim()).filter(Boolean);

  // 从后往前找，优先找短行且不像说明文的
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].replace(/^[\"'\"'\"'\"'\"'\"']+/, "").replace(/[\"'\"'\"'\"'\"'\"']+$/, "").trim();
    if (line.length >= 5 && line.length <= 240 && !isVerboseExplanationChunk(line)) {
      return line.slice(0, 900);
    }
  }

  // 如果都失败了，找包含英文关键词的行
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].replace(/^[\"'\"'\"'\"'\"'\"']+/, "").replace(/[\"'\"'\"'\"'\"'\"']+$/, "").trim();
    if (/[a-zA-Z]{3,}/.test(line) && line.length >= 10 && line.length <= 300) {
      if (!isVerboseExplanationChunk(line)) {
        return line.slice(0, 900);
      }
    }
  }

  return "";
}

/** LLM 未产出时，从原文抽取化学式/英文缩写等，略好于整段中文丢进 ti: */
function asciiKeywordFallback(q) {
  const m = String(q).match(/[A-Za-z][A-Za-z0-9+\-]{1,31}/g);
  if (!m?.length) return "";
  const seen = new Set();
  const out = [];
  for (const w of m) {
    const k = w.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(w);
    if (out.join(" ").length > 220) break;
  }
  return out.join(" ").trim();
}

export async function rewriteQueryForSearch(userQuery, opts = {}) {
  const q = String(userQuery ?? "").trim();
  const fromClient = String(opts.apiKey ?? "").trim();
  const key = resolveApiKey(fromClient);
  if (!key) {
    return { effectiveQuery: q, note: "stub:no-llm-key" };
  }
  
  // 快速模式：如果查询已经是英文关键词形式，跳过LLM改写
  const isEnglishKeywords = /^[a-zA-Z0-9\s\-_+,.:;()]{10,200}$/.test(q) && 
                            !/[\u4e00-\u9fa5]/.test(q);
  if (isEnglishKeywords && !opts.forceRewrite) {
    console.log('[rewrite] Fast mode: using original English query');
    return { effectiveQuery: q, note: "fast:english-keywords" };
  }
  
  const model = sanitizeModel(opts.model);
  const url = resolveChatCompletionsUrl(opts.chatCompletionsUrl);
  const skillRaw = String(opts.personaSkill ?? "").trim();
  const skillBlock = skillRaw
    ? `The user has selected a **role / purpose skill** (may be in Chinese). Read it first; it guides domain focus and disambiguation when you output English search keywords.\n\n---\n\n${skillRaw.slice(0, 2800)}\n\n---\n\n`
    : "";
  const systemTail =
    "Translate the user's query to concise English search keywords for academic databases (arXiv/Crossref/OpenAlex). " +
    "If Chinese, translate core technical terms precisely. " +
    "Output ONLY one line of keywords, no explanation, no preamble.";
  
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000); // 5秒超时
  
  try {
    const r = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        model,
        temperature: 0.2,
        max_tokens: 256, // 给LLM足够空间输出改写结果
        messages: [
          {
            role: "system",
            content: skillBlock + systemTail,
          },
          { role: "user", content: q },
        ],
      }),
    });
    clearTimeout(timeoutId);
    
    if (!r.ok) {
      const t = await r.text();
      console.error("[rewrite] LLM HTTP", r.status, t.slice(0, 500));
      return { effectiveQuery: q, note: `rewrite:http_${r.status}` };
    }
    const j = await r.json();
    const choice = j?.choices?.[0];
    const msg = choice?.message ?? {};
    
    // DeepSeek可能将思考过程放在reasoning_content，实际输出在content
    // 但有些情况下content会包含思考过程+输出
    let text = "";
    
    // 优先尝试content
    if (msg.content) {
      text = normalizeKeywordLine(msg.content);
    }
    
    // 如果content没有有效结果，尝试reasoning_content
    if (!text && msg.reasoning_content) {
      text = normalizeKeywordLine(msg.reasoning_content);
    }
    
    // 如果还是没有，尝试合并两者
    if (!text && msg.content && msg.reasoning_content) {
      text = normalizeKeywordLine(msg.content + "\n" + msg.reasoning_content);
    }
    
    if (text && isVerboseExplanationChunk(text)) text = "";
    if (!text) {
      const fb = asciiKeywordFallback(q);
      if (fb) {
        return {
          effectiveQuery: fb,
          note: fromClient ? "rewrite:fallback-ascii:user-key" : "rewrite:fallback-ascii",
        };
      }
      console.warn("[rewrite] empty content", {
        finish: j?.choices?.[0]?.finish_reason,
        model: j?.model,
      });
      // 中文查询没有英文关键词时，使用原始查询（让API自行处理）
      return { effectiveQuery: q, note: "rewrite:empty:original" };
    }
    return {
      effectiveQuery: text,
      note: fromClient ? "llm:user-key" : "llm:ok",
    };
  } catch (e) {
    clearTimeout(timeoutId);
    if (e.name === 'AbortError') {
      console.warn('[rewrite] timeout, using fallback');
      const fb = asciiKeywordFallback(q);
      return { 
        effectiveQuery: fb || q, 
        note: fb ? "rewrite:fallback-ascii:timeout" : "rewrite:timeout:original" 
      };
    }
    console.error("[rewrite] error", e);
    return { effectiveQuery: q, note: `rewrite_error:${e?.message || "unknown"}` };
  }
}
