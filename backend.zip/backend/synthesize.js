import {
  resolveApiKey,
  resolveChatCompletionsUrl,
  sanitizeModel,
  safeHttpUrl,
  defaultModel,
} from "./rewrite.js";
import { extractPatentNumberFromPaper } from "./patentNumber.js";

function isPatentPaper(p) {
  const s = String(p?.source ?? "");
  return s === "ddg_patent" || s === "openalex_patent";
}

function isWebOnlyPaper(p) {
  const s = String(p?.source ?? "");
  return s === "mcp_web" || s === "ddg_web" || s === "dataify_web";
}

/**
 * 综述输入：专利、网页优先占位，避免合并排序后专利落在数组末尾而被前 14 条「全网」截断。
 * @param {object[]} papers
 * @param {number} max
 */
function pickPapersForSynthesis(papers, max) {
  const arr = Array.isArray(papers) ? [...papers] : [];
  const cap = Math.min(60, Math.max(1, Number(max) || 35));
  const patents = arr.filter(isPatentPaper);
  const webs = arr.filter(isWebOnlyPaper);
  const scholarly = arr.filter((p) => !isPatentPaper(p) && !isWebOnlyPaper(p));
  const maxP = Math.min(12, patents.length, cap);
  const maxW = Math.min(12, webs.length, Math.max(0, cap - maxP));
  const maxS = Math.max(0, cap - maxP - maxW);
  return [...patents.slice(0, maxP), ...webs.slice(0, maxW), ...scholarly.slice(0, maxS)];
}

/** @param {object} p @param {number} idx 1-based */
function paperBlock(p, idx) {
  const doi = String(p.doi ?? "").trim();
  const ax = String(p.id ?? p.arxiv_id ?? "")
    .replace(/^arxiv:/i, "")
    .trim();
  const title = String(p.title ?? "").slice(0, 200);
  const authors = Array.isArray(p.authors) ? p.authors.join(", ") : String(p.authors ?? "");
  const src = String(p.source ?? "");
  const absU = String(p.absUrl ?? "").trim();
  const abstRaw = String(p.summary ?? p.abstract ?? "");
  const abst = abstRaw.slice(0, ["mcp_web", "ddg_web", "ddg_patent", "dataify_web", "openalex_patent"].includes(src) ? 360 : 240);
  let idLine = "";
  if (doi) idLine = `DOI: ${doi}`;
  else if (ax) idLine = `arXiv: ${ax}`;
  else if (src === "ddg_patent" || src === "openalex_patent") {
    const pn = String(p.patentNumber ?? "").trim() || extractPatentNumberFromPaper(p);
    idLine = pn
      ? `专利公开号: ${pn}${absU ? ` | 链接: ${absU.slice(0, 220)}` : ""}`
      : absU
        ? `专利/网页条目 | URL: ${absU.slice(0, 220)}`
        : "专利条目（无链接）";
  } else if (src === "mcp_web" || src === "ddg_web" || src === "dataify_web") {
    idLine = absU ? `网页 | URL: ${absU.slice(0, 240)}` : "网页条目（无 URL）";
  } else if (src === "openalex") {
    const oid = String(p.paper_id ?? "")
      .replace(/^openalex:/i, "")
      .trim();
    idLine = oid ? `OpenAlex: ${oid}` : absU ? `OpenAlex: ${absU.slice(0, 120)}` : "OpenAlex";
  } else if (src === "scopus" && absU) idLine = `Scopus: ${absU.slice(0, 200)}`;
  else if (src === "europepmc") {
    idLine = doi ? `DOI: ${doi}` : absU ? `Europe PMC: ${absU.slice(0, 160)}` : "Europe PMC";
  } else idLine = "（无 DOI / 无 arXiv id）";
  const typeTag =
    src === "ddg_patent" || src === "openalex_patent"
      ? "专利"
      : src === "mcp_web" || src === "ddg_web" || src === "dataify_web"
        ? "网页"
        : "文献";
  return `[${idx}] 类型:${typeTag} | ${idLine}\n标题: ${title}\n作者: ${authors.slice(0, 220)}\n摘要摘录: ${abst}`;
}

const SYNTH_SYSTEM =
  "你是科研文献综述专家。请基于提供的文献摘录，生成一份结构化的文献综述。\n\n" +
  "输出要求（使用二级标题 ##）：\n\n" +
  "## 研究背景与意义\n" +
  "简述该领域的研究背景和重要性（100-150字），必须引用至少1篇相关文献：(DOI:…) 或 [n]\n\n" +
  "## 主要研究进展\n" +
  "按主题分类总结文献中的主要发现（300-500字）。每类主题必须使用 (DOI:…) 或 [n] 标注文献来源，至少引用5篇不同文献。\n\n" +
  "## 关键技术与方法\n" +
  "总结常用的研究方法、技术路线和实验手段（150-250字），必须引用至少2篇相关文献标注来源。\n\n" +
  "## 研究趋势与展望\n" +
  "基于提供的文献，分析该领域的发展趋势、存在问题及未来方向（200-300字）。此章节为综述重点，必须充分引用文献中的具体发现来支撑每个观点，使用 (DOI:…) 或 [n] 标注至少5篇不同文献来源。明确指出哪些方向已有充分研究、哪些方向存在空白或不足。\n\n" +
  "注意事项：\n" +
  "- 事实必须来自提供的文献摘录，不得编造\n" +
  "- 引用格式：论文用 (DOI:10.xxxx) 或 [n]；**网页**须写出摘录中的 **完整 URL**（可附 [n]）；**专利**须写出摘录中的 **专利公开号/申请号**（如 CN…、US…、WO…、EP…），并与 [n] 对应\n" +
  "- 摘录中带「类型:网页」「类型:专利」的条目须在正文中体现（可增「## 专利与公开情报」「## 网页检索线索」等小节，视材料合并或拆分），**不得忽略**\n" +
  "- **禁止**以「特别说明」「所选文献未涉及」「来源未覆盖」等**长段免责**代替实质内容；若无网页/专利摘录，仅用一两句说明即可；若有则必须写入对应要点\n" +
  "- 使用简体中文，语言简洁专业\n" +
  "- 总字数控制在1600字左右\n" +
  "- 四个章节都必须包含文献引用，尤其是「研究趋势与展望」章节必须引用文献支撑观点";

/** 摘录中含专利时追加到 system，强制模型输出专利小节 */
function synthPatentMandatorySuffix(patentCount) {
  const n = Math.max(0, Math.floor(Number(patentCount) || 0));
  if (!n) return "";
  return (
    `\n\n【专利输出（强制）】\n` +
    `- 上文「以下为检索到的摘录」中，含「类型:专利」共 **${n}** 条。正文**必须**包含独立小节 **## 专利与公开情报**（不可省略、不可仅用括号一句带过）。\n` +
    `- 该小节须**逐条**对应摘录中的专利：每条至少一句技术要点，并写出摘录中的**专利公开号/申请号**（若有）及**链接 URL**（若有，须与摘录一致）。\n` +
    `- **禁止**使用「摘录未涉及具体专利」「未涉及专利公开号」「无专利信息」「来源未覆盖专利」等否定或免责表述。\n` +
    `- 其它章节可与专利交叉引用，但「## 专利与公开情报」须有实质内容，不得为空。\n`
  );
}

/** 合并/仲裁阶段：避免「仅一篇提到专利」被共识步骤删光 */
function mergePatentPreserveSuffix(patentCount) {
  const n = Math.max(0, Math.floor(Number(patentCount) || 0));
  if (!n) return "";
  return (
    `\n\n【摘录含专利 ${n} 条】（**以下条款优先于**合并提示词中「仅单独一篇综述写出则删除」的一般规则）\n` +
    `- 终稿须保留专利公开号或 URL 及至少一条与摘录一致的技术要点。\n` +
    `- 若仅模型 A 或仅模型 B 写了专利内容：只要与检索摘录一致，**必须保留**，不得以「另一篇未写」为由删除。\n` +
    `- 禁止终稿声称「无专利」「摘录未涉及专利」等，除非两份综述均未出现任何可核对摘录的专利信息（此时仍不得编造）。\n`
  );
}

/**
 * 解析第二模型：请求头 x-model-b、JSON modelB，或环境变量 LLM_MODEL_B。
 * 若与主模型同名则视为未配置（避免重复调用）。
 */
export function resolveSecondaryModel(primaryModel, modelBFromClient) {
  const raw =
    String(modelBFromClient ?? "").trim() ||
    String(process.env.LLM_MODEL_B ?? "").trim();
  if (!raw) return "";
  const sec = sanitizeModel(raw);
  const pri = sanitizeModel(primaryModel);
  if (sec === pri) return "";
  return sec;
}

function avoidanceSystemSuffix(hint) {
  const h = String(hint ?? "").trim();
  if (!h) return "";
  return `\n\n【输出偏好（须遵守）】\n${h.slice(0, 2000)}`;
}

/** 单模型回退：主 Key 失败后依次用三密钥各槽再试（缓解主 LLM_API_KEY 与网关不匹配时的 401） */
async function synthesisFallbackWithTriKeys(base, primary, triCfg) {
  let fb = await runSingleSynthesisModel({ ...base, ...primary });
  if (fb.markdown) return fb;
  if (!triCfg) return fb;
  const slots = [
    { apiKey: triCfg.keyA, model: triCfg.modelA, chatCompletionsUrl: triCfg.urlA },
    { apiKey: triCfg.keyB, model: triCfg.modelB, chatCompletionsUrl: triCfg.urlB },
    { apiKey: triCfg.keyC, model: triCfg.modelC, chatCompletionsUrl: triCfg.urlC },
  ];
  for (const slot of slots) {
    if (!slot.apiKey || slot.apiKey === primary.apiKey) continue;
    const r2 = await runSingleSynthesisModel({ ...base, ...slot });
    if (r2.markdown) {
      return { markdown: r2.markdown, note: `${fb.note}·synth:fallback_tri_key_ok` };
    }
  }
  return fb;
}

/**
 * @param {{ userQuery: string; papers: object[]; apiKey: string; model: string; chatCompletionsUrl: string; personaSkill?: string; outputAvoidanceHint?: string }} args
 * @returns {Promise<{ markdown: string | null; note: string }>}
 */
async function runSingleSynthesisModel(args) {
  const papers = pickPapersForSynthesis(Array.isArray(args.papers) ? args.papers : [], 35);
  const list = papers.map((x, i) => paperBlock(x, i + 1)).join("\n\n---\n\n");
  const nPat = papers.filter(isPatentPaper).length;
  const userQuery = String(args.userQuery ?? "").trim().slice(0, 8000);
  const skillRaw = String(args.personaSkill ?? "").trim().slice(0, 2800);
  const skillPrefix = skillRaw ? `【用户身份/用途】\n${skillRaw}\n\n---\n\n` : "";
  const avoid = avoidanceSystemSuffix(args.outputAvoidanceHint);
  const patentSys = synthPatentMandatorySuffix(nPat);

  const controller = new AbortController();
  const ms = Math.min(360_000, Math.max(25_000, Number(process.env.SYNTHESIS_TIMEOUT_MS) || 120_000));
  const timeoutId = setTimeout(() => controller.abort(), ms);

  try {
    const r = await fetch(args.chatCompletionsUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${args.apiKey}`,
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        model: args.model,
        temperature: 0.3,
        max_tokens: 6000,
        messages: [
          { role: "system", content: skillPrefix + SYNTH_SYSTEM + patentSys + avoid },
          {
            role: "user",
            content:
              `用户检索问题：${userQuery}\n\n` +
              (nPat > 0 ? `【摘录统计】含「类型:专利」${nPat} 条（须按系统「专利输出（强制）」执行）。\n\n` : "") +
              `以下为检索到的摘录（含「文献 / 网页 / 专利」类型标签；共${papers.length}条）：\n\n${list}\n\n` +
              "请基于以上摘录生成综述；**网页与专利条目须纳入正文**（专利须含独立小节 **## 专利与公开情报** 及公开号或 URL，与 [n] 对应）。",
          },
        ],
      }),
    });
    clearTimeout(timeoutId);

    if (!r.ok) {
      const t = await r.text();
      console.error("[synthesize] LLM HTTP", args.model, r.status, t.slice(0, 300));
      return { markdown: null, note: `synth:http_${r.status}` };
    }
    const j = await r.json();
    const text = String(j?.choices?.[0]?.message?.content ?? "").trim();
    if (!text) return { markdown: null, note: "synth:empty" };
    return { markdown: text.trim(), note: "synth:ok" };
  } catch (e) {
    clearTimeout(timeoutId);
    console.error("[synthesize] error", args.model, e);
    return { markdown: null, note: `synth_err:${e?.message || "unknown"}` };
  }
}

/**
 * @param {{ userQuery: string; markdownA: string; markdownB: string; apiKey: string; model: string; chatCompletionsUrl: string; personaSkill?: string; outputAvoidanceHint?: string; arbitratorMode?: boolean; excerptPatentCount?: number }} args
 */
async function mergeConsensusMarkdown(args) {
  const userQuery = String(args.userQuery ?? "").trim().slice(0, 8000);
  const a = String(args.markdownA ?? "").trim().slice(0, 12_000);
  const b = String(args.markdownB ?? "").trim().slice(0, 12_000);
  const skillRaw = String(args.personaSkill ?? "").trim().slice(0, 2000);
  const skillPrefix = skillRaw ? `【用户身份/用途】\n${skillRaw}\n\n---\n\n` : "";
  const avoid = avoidanceSystemSuffix(args.outputAvoidanceHint);
  const arbitrator = Boolean(args.arbitratorMode);
  const excerptPatentCount = Math.max(0, Math.floor(Number(args.excerptPatentCount) || 0));
  const patentMerge = mergePatentPreserveSuffix(excerptPatentCount);
  const systemArb =
    skillPrefix +
    "你是第三模型（仲裁）。已给定同一用户问题下、基于同一批文献的两份综述（模型 A 与模型 B）。请比较后输出**唯一终稿**（简体中文）。\n\n" +
    "规则：\n" +
    "- 优先保留两份中一致、可相互印证、且可由文献摘录共同支撑的论述；删除无依据的发挥。\n" +
    "- 若某一论断仅出现在其中一份：若无文献摘录支持则删去；若有摘录支持可谨慎保留并注明依据。\n" +
    "- 若两份在事实或结论上矛盾：采信更保守、与摘录更一致的一方；可用一两句话说明已仲裁分歧（勿展开争论）。\n" +
    "- 保留 (DOI:…) / [n] / arXiv 等引用格式；不得编造文献中不存在的信息。\n" +
    "- 可用二级标题 ##；篇幅可接近较长的一篇综述。" +
    (avoid
      ? "\n- 终稿还须遵守下文【输出偏好】：弱化用户不喜欢的表述方式，但不牺牲可验证事实。"
      : "") +
    patentMerge +
    avoid;
  const systemMerge =
    skillPrefix +
    "你是严谨的科学编辑。给定同一用户问题下、基于同一批文献的两份综述（模型 A 与模型 B），请只输出「共享部分」。\n\n" +
    "规则：\n" +
    "- 仅保留两份综述在事实层面一致、互相印证、或均可由文献摘录共同支撑的论述；删除仅出现在其中一份的推断、分类或强调。\n" +
    "- 若某一论断仅模型 A 或仅模型 B 写出，必须删除。\n" +
    "- 保留 (DOI:…) / [n] / arXiv 等引用格式。\n" +
    "- 使用简体中文，可用二级标题 ##；篇幅可短于单篇综述。\n" +
    "- 若交集极少，先用一两句话说明共识较少，再列出仅有的交集要点。\n" +
    "- 不得编造文献中不存在的信息。" +
    (avoid
      ? "\n- 合并后的「共享部分」还须遵守下文【输出偏好】：弱化用户不喜欢的表述方式，但不牺牲可验证的共识事实。"
      : "") +
    patentMerge +
    avoid;

  const controller = new AbortController();
  const ms = Math.min(360_000, Math.max(30_000, Number(process.env.SYNTHESIS_TIMEOUT_MS) || 150_000));
  const timeoutId = setTimeout(() => controller.abort(), ms);

  try {
    const r = await fetch(args.chatCompletionsUrl, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${args.apiKey}`,
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        model: args.model,
        temperature: arbitrator ? 0.12 : 0.15,
        max_tokens: arbitrator ? 8500 : 2200,
        messages: [
          {
            role: "system",
            content: arbitrator ? systemArb : systemMerge,
          },
          {
            role: "user",
            content:
              `用户检索问题：${userQuery}\n\n` +
              (excerptPatentCount > 0
                ? `（检索摘录中含「类型:专利」${excerptPatentCount} 条，合并/仲裁终稿须保留专利公开号或 URL 等要点。）\n\n`
                : "") +
              `--- 模型 A 综述 ---\n${a}\n\n` +
              `--- 模型 B 综述 ---\n${b}\n\n` +
              (arbitrator ? "请输出经你仲裁后的**唯一终稿**综述正文。" : "请仅输出「共享部分」综述正文。"),
          },
        ],
      }),
    });
    clearTimeout(timeoutId);

    if (!r.ok) {
      const t = await r.text();
      console.error("[synthesize/consensus] HTTP", r.status, t.slice(0, 400));
      return { markdown: null, note: `synth_consensus:http_${r.status}` };
    }
    const j = await r.json();
    const text = String(j?.choices?.[0]?.message?.content ?? "").trim();
    if (!text) return { markdown: null, note: "synth_consensus:empty" };
    return { markdown: text.trim(), note: "synth_consensus:ok" };
  } catch (e) {
    clearTimeout(timeoutId);
    console.error("[synthesize/consensus]", e);
    return { markdown: null, note: `synth_consensus_err:${e?.message || "unknown"}` };
  }
}

/**
 * 三密钥综述：A/B 各用独立 Key 并行写综述，C 用独立 Key 仲裁并输出唯一终稿（须同时配置 SYNTHESIS_API_KEY_A/B/C）。
 * @returns {null | { keyA: string; keyB: string; keyC: string; urlA: string; urlB: string; urlC: string; modelA: string; modelB: string; modelC: string }}
 */
function readTriSynthConfig(clientUrl, clientModelA, modelBHint) {
  const keyA = String(process.env.SYNTHESIS_API_KEY_A ?? "").trim();
  const keyB = String(process.env.SYNTHESIS_API_KEY_B ?? "").trim();
  const keyC = String(process.env.SYNTHESIS_API_KEY_C ?? "").trim();
  if (!keyA || !keyB || !keyC) return null;
  const urlBase = resolveChatCompletionsUrl(clientUrl);
  const urlA = safeHttpUrl(String(process.env.SYNTHESIS_CHAT_URL_A ?? "").trim()) || urlBase;
  const urlB = safeHttpUrl(String(process.env.SYNTHESIS_CHAT_URL_B ?? "").trim()) || urlBase;
  const urlC = safeHttpUrl(String(process.env.SYNTHESIS_CHAT_URL_C ?? "").trim()) || urlBase;
  const mA = sanitizeModel(
    String(process.env.SYNTHESIS_MODEL_A ?? "").trim() || String(clientModelA ?? "").trim() || defaultModel(),
  );
  const mBRaw =
    String(process.env.SYNTHESIS_MODEL_B ?? "").trim() ||
    String(modelBHint ?? "").trim() ||
    String(process.env.LLM_MODEL_B ?? "").trim() ||
    defaultModel();
  const mB = sanitizeModel(mBRaw);
  const mC = sanitizeModel(String(process.env.SYNTHESIS_MODEL_C ?? "").trim() || defaultModel());
  return { keyA, keyB, keyC, urlA, urlB, urlC, modelA: mA, modelB: mB, modelC: mC };
}

/**
 * 基于文献摘录生成文献综述（可选双模型共识；或三密钥 A/B 写、C 仲裁）
 * @param {{ userQuery: string; papers: object[]; apiKey?: string; model?: string; modelB?: string; chatCompletionsUrl?: string; personaSkill?: string }} p
 * @returns {Promise<{ markdown: string | null; plan: object | null; planNote: string | null; note: string; synthesisModels?: object }>}
 */
export async function synthesizeFromPapers(p) {
  const triCfg = readTriSynthConfig(p.chatCompletionsUrl, p.model, p.modelB);
  const key = resolveApiKey(String(p.apiKey ?? "").trim());
  if (!triCfg && !key) {
    return { markdown: null, plan: null, planNote: null, note: "synth:no-llm-key" };
  }
  const papers = Array.isArray(p.papers) ? p.papers : [];
  if (!papers.length) {
    return { markdown: null, plan: null, planNote: null, note: "synth:no-papers" };
  }
  const excerptPatentCount = pickPapersForSynthesis(papers, 35).filter(isPatentPaper).length;
  const userQuery = String(p.userQuery ?? "").trim().slice(0, 8000);
  if (!userQuery) {
    return { markdown: null, plan: null, planNote: null, note: "synth:empty-query" };
  }

  const modelA = sanitizeModel(p.model);
  const modelB = resolveSecondaryModel(p.model, p.modelB);
  const url = resolveChatCompletionsUrl(p.chatCompletionsUrl);
  const avoidHint = String(p.outputAvoidanceHint ?? "").trim().slice(0, 2000);

  if (triCfg) {
    const base = {
      userQuery,
      papers,
      personaSkill: p.personaSkill,
      outputAvoidanceHint: avoidHint || undefined,
    };
    const [ra, rb] = await Promise.all([
      runSingleSynthesisModel({
        ...base,
        apiKey: triCfg.keyA,
        model: triCfg.modelA,
        chatCompletionsUrl: triCfg.urlA,
      }),
      runSingleSynthesisModel({
        ...base,
        apiKey: triCfg.keyB,
        model: triCfg.modelB,
        chatCompletionsUrl: triCfg.urlB,
      }),
    ]);
    const synthesisModels = {
      modelA: triCfg.modelA,
      modelB: triCfg.modelB,
      modelC: triCfg.modelC,
      mode: "tri_arbitration",
    };

    if (!ra.markdown && !rb.markdown) {
      if (key) {
        const fb = await synthesisFallbackWithTriKeys(
          base,
          { apiKey: key, model: modelA, chatCompletionsUrl: url },
          triCfg,
        );
        return {
          markdown: fb.markdown,
          plan: null,
          planNote: null,
          note: fb.markdown
            ? `synth:tri_fail_then_single:${ra.note}|${rb.note}·${fb.note}`
            : `synth:tri_fail:${ra.note}|${rb.note}·single:${fb.note}`,
          synthesisModels: { ...synthesisModels, mode: "tri_fallback_single" },
        };
      }
      const fb0 = await runSingleSynthesisModel({
        ...base,
        apiKey: triCfg.keyA,
        model: triCfg.modelA,
        chatCompletionsUrl: triCfg.urlA,
      });
      return {
        markdown: fb0.markdown,
        plan: null,
        planNote: null,
        note: fb0.markdown
          ? `synth:tri_fail_then_slot_a:${ra.note}|${rb.note}·${fb0.note}`
          : `synth:tri_fail:${ra.note}|${rb.note}·${fb0.note}`,
        synthesisModels: { ...synthesisModels, mode: "tri_fallback_slot_a_only" },
      };
    }
    if (!ra.markdown) {
      return {
        markdown: rb.markdown,
        plan: null,
        planNote: null,
        note: `${rb.note}·synth:tri_fallback_b_only`,
        synthesisModels: { ...synthesisModels, mode: "tri_partial" },
      };
    }
    if (!rb.markdown) {
      return {
        markdown: ra.markdown,
        plan: null,
        planNote: null,
        note: `${ra.note}·synth:tri_fallback_a_only`,
        synthesisModels: { ...synthesisModels, mode: "tri_partial" },
      };
    }

    const merged = await mergeConsensusMarkdown({
      userQuery,
      markdownA: ra.markdown,
      markdownB: rb.markdown,
      apiKey: triCfg.keyC,
      model: triCfg.modelC,
      chatCompletionsUrl: triCfg.urlC,
      personaSkill: p.personaSkill,
      outputAvoidanceHint: avoidHint || undefined,
      arbitratorMode: true,
      excerptPatentCount,
    });

    if (!merged.markdown) {
      const pick =
        (ra.markdown?.length || 0) >= (rb.markdown?.length || 0) ? ra.markdown : rb.markdown;
      if (pick && key) {
        const fb = await synthesisFallbackWithTriKeys(
          base,
          { apiKey: key, model: modelA, chatCompletionsUrl: url },
          triCfg,
        );
        if (fb.markdown) {
          return {
            markdown: fb.markdown,
            plan: null,
            planNote: null,
            note: `synth:tri_arb_failed_then_single:${merged.note}·${fb.note}`,
            synthesisModels: { ...synthesisModels, mode: "tri_fallback_single_after_arb" },
          };
        }
      }
      if (pick) {
        return {
          markdown: pick,
          plan: null,
          planNote: null,
          note: `synth:tri_arb_failed_use_longer_branch:${merged.note}`,
          synthesisModels: { ...synthesisModels, mode: "tri_partial_no_arb" },
        };
      }
      return {
        markdown: null,
        plan: null,
        planNote: null,
        note: `synth:tri_arbitration_failed:${merged.note}`,
        synthesisModels,
      };
    }

    return {
      markdown: merged.markdown,
      plan: null,
      planNote: null,
      note: "synth:tri_arbitration_ok",
      synthesisModels,
    };
  }

  const base = {
    userQuery,
    papers,
    apiKey: key,
    chatCompletionsUrl: url,
    personaSkill: p.personaSkill,
    outputAvoidanceHint: avoidHint || undefined,
  };

  if (!modelB) {
    const one = await runSingleSynthesisModel({ ...base, model: modelA });
    return {
      markdown: one.markdown,
      plan: null,
      planNote: null,
      note: one.note,
      synthesisModels: { modelA, modelB: null, mode: "single" },
    };
  }

  const [ra, rb] = await Promise.all([
    runSingleSynthesisModel({ ...base, model: modelA }),
    runSingleSynthesisModel({ ...base, model: modelB }),
  ]);

  const synthesisModels = { modelA, modelB, mode: "dual_consensus" };

  if (!ra.markdown && !rb.markdown) {
    return {
      markdown: null,
      plan: null,
      planNote: null,
      note: `synth:dual_fail:${ra.note}|${rb.note}`,
      synthesisModels,
    };
  }
  if (!ra.markdown) {
    return {
      markdown: rb.markdown,
      plan: null,
      planNote: null,
      note: `${rb.note}·synth:dual_fallback_b_only`,
      synthesisModels: { ...synthesisModels, mode: "dual_partial" },
    };
  }
  if (!rb.markdown) {
    return {
      markdown: ra.markdown,
      plan: null,
      planNote: null,
      note: `${ra.note}·synth:dual_fallback_a_only`,
      synthesisModels: { ...synthesisModels, mode: "dual_partial" },
    };
  }

  const merged = await mergeConsensusMarkdown({
    userQuery,
    markdownA: ra.markdown,
    markdownB: rb.markdown,
    apiKey: key,
    model: modelA,
    chatCompletionsUrl: url,
    personaSkill: p.personaSkill,
    outputAvoidanceHint: avoidHint || undefined,
    arbitratorMode: false,
    excerptPatentCount,
  });

  if (!merged.markdown) {
    return {
      markdown: null,
      plan: null,
      planNote: null,
      note: `synth:dual_consensus_failed:${merged.note}`,
      synthesisModels,
    };
  }

  return {
    markdown: merged.markdown,
    plan: null,
    planNote: null,
    note: "synth:dual_consensus_ok",
    synthesisModels,
  };
}
