/**
 * Dataify 搜索引擎 API（可选）：配置 DATAIFY_API_KEY 后，「网页」渠道优先用其拉取 SERP 式结果。
 *
 * 默认请求：GET {DATAIFY_API_BASE}{DATAIFY_WEB_PATH}?{DATAIFY_WEB_QUERY_PARAM}=...
 * 鉴权：{DATAIFY_AUTH_HEADER}: {DATAIFY_AUTH_PREFIX}{DATAIFY_API_KEY}
 *
 * 若控制台文档与默认不一致，可设：
 * - DATAIFY_WEB_METHOD=POST
 * - DATAIFY_WEB_BODY_JSON：JSON 字符串，其中 {{QUERY}}、{{API_KEY}} 会被替换（避免与 JSON 花括号冲突）
 * - DATAIFY_WEB_URL：完整 URL 模板，含 {{QUERY}}（URL 编码后替换）；与 path 二选一优先用此
 * - DATAIFY_EXTRA_HEADERS_JSON：合并到请求头的 JSON 对象
 *
 * 成功响应：兼容常见形态（code 为 0/200、或顶层即列表）；从 JSON 中递归收集含 http(s) 的 url/title/snippet 字段。
 */

import crypto from "node:crypto";
import { extractDoiCandidate } from "./doi.js";

function stableWebId(url) {
  return crypto.createHash("sha256").update(url).digest("hex").slice(0, 22);
}

/** @param {unknown} obj @param {Array<{url:string,title:string,description:string}>} out */
function collectUrlResults(obj, out, depth) {
  if (depth > 14 || obj == null) return;
  if (Array.isArray(obj)) {
    for (const x of obj) collectUrlResults(x, out, depth + 1);
    return;
  }
  if (typeof obj !== "object") return;
  const o = /** @type {Record<string, unknown>} */ (obj);
  const url = o.url ?? o.URL ?? o.href ?? o.link ?? o.uri;
  const title = o.title ?? o.name ?? o.heading ?? "";
  const desc = o.description ?? o.snippet ?? o.body ?? o.summary ?? o.text ?? "";
  if (typeof url === "string" && /^https?:\/\//i.test(url)) {
    out.push({
      url: url.split("#")[0],
      title: String(title || "Web").slice(0, 400),
      description: String(desc).slice(0, 1200),
    });
  }
  for (const k of Object.keys(o)) collectUrlResults(o[k], out, depth + 1);
}

/** @param {unknown} body */
function unwrapDataifyPayload(body) {
  if (body == null || typeof body !== "object") return body;
  const o = /** @type {Record<string, unknown>} */ (body);
  const code = o.code;
  if (code !== undefined && code !== null && code !== 0 && code !== 200 && code !== "0" && code !== "200") {
    return null;
  }
  if (o.success === false) return null;
  if (o.data !== undefined) return o.data;
  if (o.result !== undefined) return o.result;
  return o;
}

/** @returns {null | { apiKey: string, base: string, path: string, method: string, queryParam: string, timeoutMs: number, maxResults: number, authHeader: string, authPrefix: string, urlTemplate: string, bodyTemplate: string, extraHeaders: Record<string, string> }} */
export function getDataifyWebSearchConfig() {
  const apiKey = String(process.env.DATAIFY_API_KEY ?? "").trim();
  if (!apiKey) return null;

  const base = String(process.env.DATAIFY_API_BASE ?? "https://api.dataify.com").trim().replace(/\/+$/, "");
  const path = String(process.env.DATAIFY_WEB_PATH ?? "/v1/search").trim();
  const pathNorm = path.startsWith("/") ? path : `/${path}`;
  const method = String(process.env.DATAIFY_WEB_METHOD ?? "GET").trim().toUpperCase() || "GET";
  const queryParam = String(process.env.DATAIFY_WEB_QUERY_PARAM ?? "q").trim() || "q";
  const timeoutMs = Math.min(60_000, Math.max(3000, Number(process.env.DATAIFY_WEB_TIMEOUT_MS) || 14_000));
  const maxResults = Math.min(35, Math.max(1, Number(process.env.DATAIFY_WEB_MAX_RESULTS) || 15));
  const authHeader = String(process.env.DATAIFY_AUTH_HEADER ?? "Authorization").trim() || "Authorization";
  const authPrefix = process.env.DATAIFY_AUTH_PREFIX !== undefined ? String(process.env.DATAIFY_AUTH_PREFIX) : "Bearer ";

  const urlTemplate = String(process.env.DATAIFY_WEB_URL ?? "").trim();
  const bodyTemplate = String(process.env.DATAIFY_WEB_BODY_JSON ?? "").trim();

  let extraHeaders = {};
  try {
    const raw = String(process.env.DATAIFY_EXTRA_HEADERS_JSON ?? "").trim();
    if (raw) {
      const j = JSON.parse(raw);
      if (j && typeof j === "object" && !Array.isArray(j)) {
        extraHeaders = Object.fromEntries(
          Object.entries(j).map(([k, v]) => [String(k), String(v)]),
        );
      }
    }
  } catch {
    extraHeaders = {};
  }

  return {
    apiKey,
    base,
    path: pathNorm,
    method,
    queryParam,
    timeoutMs,
    maxResults,
    authHeader,
    authPrefix,
    urlTemplate,
    bodyTemplate,
    extraHeaders,
  };
}

/**
 * @param {unknown} json
 * @param {number} max
 * @param {string} sourceLabel
 */
function jsonToWebPapers(json, max, sourceLabel) {
  const rawItems = [];
  const unwrapped = unwrapDataifyPayload(json);
  if (unwrapped != null) collectUrlResults(unwrapped, rawItems, 0);
  else collectUrlResults(json, rawItems, 0);

  const seen = new Set();
  const papers = [];
  for (const it of rawItems) {
    const u = String(it.url || "").trim();
    if (!u || seen.has(u)) continue;
    seen.add(u);
    const doi = extractDoiCandidate(`${u} ${it.description}`) || extractDoiCandidate(it.title);
    const id = stableWebId(u);
    const summary = it.description || it.title;
    papers.push({
      paper_id: `${sourceLabel}:${id}`,
      doi,
      title: it.title || u,
      abstract: summary,
      year: null,
      venue: "Web (Dataify)",
      oa_status: null,
      authors_json: JSON.stringify([]),
      authors: [],
      summary,
      published: "",
      id,
      absUrl: u,
      pdfUrl: u,
      source: sourceLabel,
      isReferencedByCount: null,
    });
    if (papers.length >= max) break;
  }
  return papers;
}

/**
 * @param {string} query
 * @param {number} max
 * @returns {Promise<{ papers: object[]; note: string; toolName?: string }>}
 */
export async function fetchDataifyWebPapers(query, max) {
  const cfg = getDataifyWebSearchConfig();
  if (!cfg) return { papers: [], note: "disabled" };

  const q = String(query ?? "").trim();
  if (!q) return { papers: [], note: "empty-query" };

  const cap = Math.min(max || 15, cfg.maxResults);
  let url = "";
  let body = undefined;
  const headers = {
    Accept: "application/json",
    "User-Agent": "QuantumPinnacle/1.0 (+https://github.com/)",
    ...cfg.extraHeaders,
  };

  const authValue = cfg.authPrefix ? `${cfg.authPrefix}${cfg.apiKey}` : cfg.apiKey;
  if (cfg.authHeader) headers[cfg.authHeader] = authValue;

  if (cfg.urlTemplate) {
    url = cfg.urlTemplate.split("{{QUERY}}").join(encodeURIComponent(q.slice(0, 2000)));
  } else if (cfg.method === "GET") {
    const u = new URL(cfg.path, cfg.base.endsWith("/") ? cfg.base : `${cfg.base}/`);
    u.searchParams.set(cfg.queryParam, q.slice(0, 2000));
    url = u.toString();
  } else {
    const u = new URL(cfg.path, cfg.base.endsWith("/") ? cfg.base : `${cfg.base}/`);
    url = u.toString();
    if (cfg.bodyTemplate) {
      const qInner = JSON.stringify(q.slice(0, 2000)).slice(1, -1);
      const kInner = JSON.stringify(cfg.apiKey).slice(1, -1);
      body = cfg.bodyTemplate.replace(/\{\{QUERY\}\}/g, qInner).replace(/\{\{API_KEY\}\}/g, kInner);
      headers["Content-Type"] = headers["Content-Type"] || "application/json";
    }
  }

  if (!url) return { papers: [], note: "no-url" };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), cfg.timeoutMs);
  try {
    const init = {
      method: cfg.method,
      headers,
      signal: controller.signal,
    };
    if (cfg.method !== "GET" && body !== undefined) init.body = body;
    const res = await fetch(url, init);
    const text = await res.text();
    if (!res.ok) {
      console.warn("[dataify_web] HTTP", res.status, text.slice(0, 240));
      return { papers: [], note: `http_${res.status}`, toolName: "dataify" };
    }
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      return { papers: [], note: "non-json", toolName: "dataify" };
    }
    if (json && typeof json === "object" && "code" in json) {
      const c = /** @type {{ code: unknown }} */ (json).code;
      if (typeof c === "number" && c !== 0 && c !== 200) {
        const msg = /** @type {{ message?: string }} */ (json).message;
        console.warn("[dataify_web] api code:", c, msg || "");
        return { papers: [], note: `api_code:${c}`, toolName: "dataify" };
      }
      if (typeof c === "string" && c !== "0" && c !== "200" && c.toLowerCase() !== "ok" && c.toLowerCase() !== "success") {
        const msg = /** @type {{ message?: string }} */ (json).message;
        console.warn("[dataify_web] api code:", c, msg || "");
        return { papers: [], note: `api_code:${c}`, toolName: "dataify" };
      }
    }
    const papers = jsonToWebPapers(json, cap, "dataify_web");
    return {
      papers,
      note: papers.length ? "ok" : "no-url-results",
      toolName: "dataify",
    };
  } catch (e) {
    const msg = e?.name === "AbortError" ? "timeout" : String(e?.message || e).slice(0, 120);
    console.warn("[dataify_web] fetch failed:", msg);
    return { papers: [], note: `err:${msg}`, toolName: "dataify" };
  } finally {
    clearTimeout(timer);
  }
}
