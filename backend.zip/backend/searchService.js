import { upsertPapers, searchLocalPapers, searchDoiRecords, searchFullPapers, isPostgres } from "./db.js";
import { buildArxivSearchQuery, fetchArxiv, mapArxivSort } from "./arxiv.js";
import { fetchCrossrefWorkByDoi, fetchCrossrefWorks } from "./crossref.js";
import { extractDoiCandidate } from "./doi.js";
import { rewriteQueryForSearch } from "./rewrite.js";
import { fetchMcpWebPapers, fetchPatentPapers, fetchDuckDuckGoSearch, isMcpUsable } from "./mcpWebSearch.js";
import { fetchDataifyWebPapers, getDataifyWebSearchConfig } from "./dataifyWebSearch.js";
import { fetchOpenAlexWorks, fetchOpenAlexPatents } from "./openalex.js";
import { fetchEuropePmcWorks } from "./europePmc.js";
import { fetchScopusWorks, getElsevierScopusConfig } from "./scopusElsevier.js";
import { fetchSemanticScholarWorks, fetchSemanticScholarByDoi } from "./semanticScholar.js";
import { strictRecommendFilterAndRank } from "./paperRecommendFilter.js";
import { raceWithTimeout } from "./fetchWithTimeout.js";
import { searchCache, rewriteCache } from "./cache.js";
import { extractPatentNumberFromPaper } from "./patentNumber.js";

/** @param {object} p */
function isPatentSourcePaper(p) {
  const s = String(p?.source ?? "");
  return s === "ddg_patent" || s === "openalex_patent";
}

/**
 * 仅专利模式：只保留专利类条目，并尽量写入 patentNumber（便于列表与导出）。
 * @param {object[]} papers
 * @param {number} max
 */
function finalizePatentsOnlyRows(papers, max) {
  const cap = Math.min(200, Math.max(1, Number(max) || 40));
  const arr = Array.isArray(papers) ? papers.filter(isPatentSourcePaper) : [];
  const out = [];
  for (const p of arr) {
    const pn = String(p.patentNumber ?? "").trim() || extractPatentNumberFromPaper(p);
    out.push(pn ? { ...p, patentNumber: pn } : { ...p });
    if (out.length >= cap) break;
  }
  return out;
}

function normTitle(t) {
  return String(t ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fff]+/gi, " ")
    .trim()
    .slice(0, 160);
}

function dedupeKey(p) {
  const doi = String(p.doi ?? "").trim().toLowerCase();
  if (doi) return `doi:${doi}`;
  if ((p.source === "mcp_web" || p.source === "dataify_web" || p.source === "ddg_patent" || p.source === "openalex_patent") && p.absUrl) {
    return `url:${String(p.absUrl).split("#")[0].toLowerCase()}`;
  }
  const auth = (p.authors ?? []).join(",").toLowerCase().replace(/\s+/g, " ").slice(0, 100);
  return `t:${normTitle(p.title)}|a:${auth}|y:${p.year ?? ""}`;
}

function scoreSource(x) {
  if (x.source === "local") return 3;
  /** 爱思唯尔 Scopus：合并去重时优先保留该来源的题录与摘要 */
  if (x.source === "scopus") return 10;
  if (x.source === "arxiv") return 2;
  if (x.source === "dataify_web") return 2.22;
  if (x.source === "mcp_web") return 2.15;
  if (x.source === "ddg_web") return 2.1;
  if (x.source === "ddg_patent") return 2.2;
  if (x.source === "openalex") return 1.05;
  /** OpenAlex 专利索引 */
  if (x.source === "openalex_patent") return 1.35;
  /** Europe PMC 生物医学等开放检索 */
  if (x.source === "europepmc") return 1.55;
  if (x.source === "semantic_scholar") return 1.8; // Semantic Scholar 优先级较高
  return 1;
}

/** 从用户问题抽取英文/化学式类 token，用于剔除与问题词**零交集**的跑题结果 */
function extractQueryTokens(raw) {
  const m = String(raw ?? "").match(/[A-Za-z\u00C0-\u024f][A-Za-z0-9+\-]{2,}/g);
  if (!m?.length) return [];
  const noise = new Set([
    "the",
    "and",
    "for",
    "are",
    "was",
    "has",
    "not",
    "can",
    "use",
    "may",
    "new",
    "all",
    "any",
    "with",
    "from",
    "this",
    "that",
    "into",
  ]);
  const seen = new Set();
  const out = [];
  for (const w of m) {
    const k = w.toLowerCase();
    if (k.length < 3 || noise.has(k)) continue;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(k);
    if (out.length >= 22) break;
  }
  return out;
}

function countTokenHits(paper, tokens) {
  const raw = `${paper.title || ""} ${paper.summary || paper.abstract || ""}`;
  const blob = raw.toLowerCase();
  let n = 0;
  for (const t of tokens) {
    const s = String(t);
    if (/[\u4e00-\u9fff]/.test(s)) {
      if (raw.includes(s)) n++;
    } else {
      const tl = s.toLowerCase();
      if (tl.length >= 2 && blob.includes(tl)) n++;
    }
  }
  return n;
}

/** 用户问题中的中文短语，用于与题录/摘要匹配 */
function extractChinesePhrases(raw) {
  const m = String(raw ?? "").match(/[\u4e00-\u9fff]{2,12}/g);
  if (!m?.length) return [];
  const seen = new Set();
  const out = [];
  for (const w of m) {
    if (seen.has(w)) continue;
    seen.add(w);
    out.push(w);
    if (out.length >= 14) break;
  }
  return out;
}

/** 用户喜好 / 侧栏收藏关键词（字符串数组），并入相关性 token */
function normalizePreferenceKeywords(preferenceKeywords) {
  if (!Array.isArray(preferenceKeywords)) return [];
  const seen = new Set();
  const out = [];
  for (const item of preferenceKeywords) {
    const s = String(item ?? "").trim().slice(0, 96);
    if (!s) continue;
    for (const w of [...extractQueryTokens(s), ...extractChinesePhrases(s)]) {
      const k = /[\u4e00-\u9fff]/.test(w) ? w : w.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(w);
      if (out.length >= 20) return out;
    }
  }
  return out;
}

/** 合并用户原文、LLM 英文检索词与喜好词（纯中文问题时仅靠 raw 抽不到词，噪声无法剔除） */
function extractQueryTokensMerged(rawQuery, effectiveQuery, preferenceKeywords) {
  const seen = new Set();
  const out = [];
  const sources = [
    ...extractQueryTokens(rawQuery),
    ...extractQueryTokens(effectiveQuery),
    ...extractChinesePhrases(rawQuery),
    ...normalizePreferenceKeywords(preferenceKeywords),
  ];
  for (const w of sources) {
    const k = /[\u4e00-\u9fff]/.test(w) ? w : w.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(w);
    if (out.length >= 40) break;
  }
  return out;
}

/**
 * 若至少两条文献命中用户问题里的专业词，且存在 ≥3 条完全零命中，则丢掉零命中条目（缓解 arXiv/Crossref 噪声）。
 * 修改：放宽条件，确保不会过滤掉太多结果
 */
function dropZeroRelevanceByTokens(papers, rawQuery, effectiveQuery, preferenceKeywords) {
  const tokens = extractQueryTokensMerged(rawQuery, effectiveQuery, preferenceKeywords);
  const isChineseQuery = /[\u4e00-\u9fff]/.test(String(rawQuery ?? "")) && /[\u4e00-\u9fff]/.test(String(effectiveQuery ?? ""));
  if (isChineseQuery) return papers;
  // 放宽条件：token不够多或论文太少跳过过滤
  if (tokens.length < 2 || papers.length <= 15) return papers;
  const scored = papers.map((p) => ({ p, c: countTokenHits(p, tokens) }));
  const isPatentSrc = (p) => {
    const s = String(p?.source ?? "");
    return s === "ddg_patent" || s === "openalex_patent";
  };
  const withHits = scored.filter((x) => x.c > 0 || isPatentSrc(x.p));
  const withoutHits = scored.filter((x) => x.c === 0 && !isPatentSrc(x.p));
  // 放宽：有命中项的至少占50%
  if (withHits.length < 3) return papers;
  if (withoutHits.length < 3) return papers;
  if (withHits.length < papers.length * 0.3) return papers;
  return withHits.map((x) => x.p);
}

function mergeDedupe(lists) {
  const map = new Map();
  for (const list of lists) {
    for (const p of list) {
      const k = dedupeKey(p);
      const prev = map.get(k);
      if (!prev) {
        map.set(k, p);
        continue;
      }
      if (scoreSource(p) >= scoreSource(prev)) {
        map.set(k, {
          ...prev,
          ...p,
          authors: p.authors?.length ? p.authors : prev.authors,
          summary: (p.summary || p.abstract || "").length >= (prev.summary || "").length ? p.summary || p.abstract : prev.summary,
        });
      }
    }
  }
  return [...map.values()];
}

function rowToApiPaper(row) {
  let authors = [];
  try {
    // 兼容 authors_json（原始列名）和 authors（searchLocalPapers 别名）
    authors = JSON.parse(row.authors_json || row.authors || "[]");
  } catch {
    authors = [];
  }
  const arxivId = row.arxiv_id || String(row.paper_id || "").replace(/^arxiv:/, "") || row.paper_id;
  // 兼容 abstract（原始列名）和 summary（searchLocalPapers 别名）
  const abstract = row.abstract || row.summary || "";
  const pid = String(row.paper_id ?? "").trim();
  const venue = String(row.venue ?? row.journal ?? "").trim();
  const isPatent =
    pid.startsWith("openalex_patent:") ||
    pid.startsWith("ddg_patent:") ||
    pid.startsWith("local:patent:") ||
    /\bpatent\b/i.test(venue);
  return {
    paper_id: row.paper_id,
    doi: row.doi,
    title: row.title,
    summary: abstract,
    abstract: abstract,
    year: row.year,
    venue: venue,
    published: row.year ? `${row.year}-01-01` : "",
    authors,
    id: arxivId,
    absUrl: row.abs_url,
    pdfUrl: row.pdf_url,
    source: isPatent ? "openalex_patent" : "local",
    oa_status: row.oa_status,
    isReferencedByCount: null,
    patentNumber: isPatent ? (row.patentNumber || row.patent_number || extractPatentNoFromVenueUrl(venue, row.abs_url)) : undefined,
  };
}

function extractPatentNoFromVenueUrl(venue, absUrl) {
  const blob = `${venue} ${absUrl || ""}`;
  const m = blob.match(/\b(?:US|EP|WO|CN|JP|KR|DE|FR|GB|TW|IN)\s*[-_]?\s*\d[\d,\s]{4,}\s*[A-Z0-9]?\b/i);
  return m ? m[0].replace(/[\s,]+/g, "").slice(0, 48) : "";
}

function toIngestRows(papers) {
  const now = Date.now();
  return papers.map((p) => ({
    paper_id: p.paper_id,
    doi: p.doi,
    title: p.title,
    abstract: p.abstract ?? p.summary ?? "",
    year: p.year,
    venue: p.venue,
    oa_status: p.oa_status,
    arxiv_id: p.arxiv_id ?? null,
    authors_json: JSON.stringify(p.authors ?? []),
    abs_url: p.absUrl,
    pdf_url: p.pdfUrl,
    patentNumber: p.patentNumber ?? null,
    created_at: now,
  }));
}

/**
 * 将 material_kb 数据库的 papers 表行转换为 API 格式
 * @param {Object} row
 * @returns {Object}
 */
function materialKbRowToApiPaper(row) {
  let authors = [];
  try {
    authors = JSON.parse(row.authors_json || row.authors || "[]");
  } catch {
    authors = row.authors ? row.authors.split(",").map(a => a.trim()) : [];
  }
  return {
    paper_id: row.paper_id || row.id || row.doi,
    doi: row.doi,
    title: row.title,
    summary: row.abstract || "",
    abstract: row.abstract || "",
    year: row.year,
    venue: row.journal || row.venue,
    published: row.year ? `${row.year}-01-01` : "",
    authors,
    id: row.doi || row.paper_id,
    absUrl: row.url || row.abs_url,
    pdfUrl: row.pdf_url,
    source: "local",
    oa_status: row.oa_status,
    isReferencedByCount: row.citation_count || null,
    // 材料科学11个要素
    category: row.category,
    material_name: row.material_name,
    symmetry_phase: row.symmetry_phase,
    structure_descriptor: row.structure_descriptor,
    properties: row.properties,
    applications: row.applications,
    synthesis_method: row.synthesis_method,
    characterization_method: row.characterization_method,
    quality_control: row.quality_control,
    first_author: row.first_author,
    corresponding_author: row.corresponding_author,
    relevance_score: row.relevance_score,
    credibility_score: row.credibility_score,
  };
}

/**
 * 将 doi_records 表行转换为 API 格式
 * @param {Object} row
 * @returns {Object}
 */
function doiRecordToApiPaper(row) {
  let authors = [];
  try {
    authors = JSON.parse(row.authors || "[]");
  } catch {
    authors = row.authors ? row.authors.split(",").map(a => a.trim()) : [];
  }
  // 确保 title 也复制到 summary/abstract，以便 token 匹配能正常工作
  const title = row.title || "";
  return {
    paper_id: `doi:${row.doi}`,
    doi: row.doi,
    title: title,
    summary: title,  // 复制标题到 summary，确保 countTokenHits 能匹配
    abstract: title, // 复制标题到 abstract，确保 countTokenHits 能匹配
    year: row.year,
    venue: row.journal,
    published: row.publish_date || (row.year ? `${row.year}-01-01` : ""),
    authors,
    id: row.doi,
    absUrl: row.url,
    pdfUrl: null,
    source: "local",
    oa_status: null,
    isReferencedByCount: null,
  };
}

function timeMs(p) {
  const d = Date.parse(p.published || "");
  return Number.isFinite(d) ? d : 0;
}

function applySort(merged, sort) {
  const out = [...merged];
  if (sort === "relevance") return out;
  if (sort === "citations") {
    out.sort(
      (a, b) =>
        (b.isReferencedByCount || 0) - (a.isReferencedByCount || 0) ||
        String(a.paper_id).localeCompare(String(b.paper_id)),
    );
    return out;
  }
  if (sort === "submittedDate" || sort === "lastUpdatedDate") {
    out.sort(
      (a, b) => timeMs(b) - timeMs(a) || String(a.paper_id).localeCompare(String(b.paper_id)),
    );
    return out;
  }
  out.sort((a, b) => String(a.paper_id).localeCompare(String(b.paper_id)));
  return out;
}

/**
 * @param {object} opts
 * @param {string} opts.rawQuery
 * @param {'database'|'web'} opts.channel
 * @param {boolean} [opts.useMcpWeb] 为 false 时不外呼专利/全网网页补充（默认 true）；文献库与其它源仍照常检索
 * @param {'ti'|'abs'|'all'} opts.field
 * @param {string} opts.sort
 * @param {number} opts.max
 * @param {boolean} [opts.useLlmRewrite]
 * @param {string} [opts.openaiApiKey] 用户请求头传入的 LLM Key（X-OpenAI-Key / X-DeepSeek-Key 等，不在日志中落库）
 * @param {string} [opts.openaiModel] 模型名
 * @param {string} [opts.llmChatCompletionsUrl] 兼容接口完整 URL（…/chat/completions）
 * @param {string} [opts.personaSkill] 用户身份 Skill 全文，先于默认策略参与检索式改写
 * @param {boolean} [opts.patentsOnly] 为 true 时仅外呼专利源（OpenAlex 专利 + DDG/MCP 专利），结果只含专利条目并补全 patentNumber
 */
export async function runPaperSearch(opts) {
  const started = Date.now();
  const channel = opts.channel === "web" ? "web" : "database";
  const useMcpWeb = opts.useMcpWeb !== false;
  const field = opts.field === "ti" || opts.field === "abs" ? opts.field : "all";
  /** 上限：数据库渠道可略大；网页多源外呼略保守 */
  const maxCap = channel === "database" ? 220 : 180;
  /** 条数不固定：默认中等池，由下游强相关过滤决定最终条数 */
  const defaultMax = channel === "database" ? 100 : 70;
  const max = Math.min(maxCap, Math.max(1, Number(opts.max) || defaultMax));
  const sort = opts.sort || "relevance";
  const useLlm = opts.useLlmRewrite !== false;
  const patentsOnly = opts.patentsOnly === true;

  /** 网页渠道：强制要求配置爱思唯尔 Scopus（ELSEVIER_API_KEY），否则无法检索（仅专利模式不依赖 Scopus） */
  if (
    channel === "web" &&
    !patentsOnly &&
    !getElsevierScopusConfig() &&
    String(process.env.ALLOW_WEB_WITHOUT_ELSEVIER ?? "").trim() !== "1"
  ) {
    const err = new Error(
      "网页渠道已强制使用爱思唯尔 Scopus：请在本机 .env 配置 ELSEVIER_API_KEY（https://dev.elsevier.com 申请），机构环境可配置 ELSEVIER_INST_TOKEN；保存后重启 API。",
    );
    err.code = "ELSEVIER_REQUIRED";
    throw err;
  }

  // 先处理rewrite，因为effectiveQuery可能影响缓存键
  // 检查rewrite缓存
  const rewriteCacheKey = searchCache.constructor.key('rewrite', {
    q: opts.rawQuery,
    useLlm,
    model: opts.openaiModel,
    personaSkill: opts.personaSkill?.slice(0, 50),
  });
  let rw = rewriteCache.get(rewriteCacheKey);
  
  if (!rw) {
    rw = useLlm
      ? await rewriteQueryForSearch(opts.rawQuery, {
          apiKey: opts.openaiApiKey,
          model: opts.openaiModel,
          chatCompletionsUrl: opts.llmChatCompletionsUrl,
          personaSkill: opts.personaSkill,
        })
      : { effectiveQuery: opts.rawQuery, note: "rewrite:skipped" };
    rewriteCache.set(rewriteCacheKey, rw);
  } else {
    console.log(`[rewrite] cache hit for "${opts.rawQuery.slice(0, 30)}..."`);
  }
  
  // 如果改写结果为空或无效，使用原始查询
  let effectiveQuery = rw.effectiveQuery || String(opts.rawQuery ?? "").trim();
  const rawQuery = String(opts.rawQuery ?? "").trim();
  // 检测无效改写结果：空、乱码、中文胡说八道、unrecognized等
  const isInvalidRewrite = !effectiveQuery 
    || effectiveQuery === "??" 
    || effectiveQuery === "unrecognized input"
    || /^(?:鉴于|由于|因为|所以|因此|然而|但是|输入|输出|unrecognized|invalid|error)/i.test(effectiveQuery);
  if (isInvalidRewrite) {
    console.log(`[rewrite] invalid effectiveQuery "${effectiveQuery.slice(0, 50)}", falling back to raw query`);
    effectiveQuery = rawQuery;
    rw.note = (rw.note || "") + " · rewrite:invalid-fallback";
  }
  // 中文查询：如果改写后没有中文且原始查询有中文，优先使用原始查询让本地数据库匹配
  if (/[\u4e00-\u9fff]/.test(rawQuery) && !/[\u4e00-\u9fff]/.test(effectiveQuery) && effectiveQuery !== rawQuery) {
    console.log(`[rewrite] Chinese query detected, using raw query for local db matching`);
    effectiveQuery = rawQuery;
    rw.note = (rw.note || "") + " · rewrite:chinese-raw";
  }
  
  // 检查搜索结果缓存 - 使用原始查询+effectiveQuery作为缓存键
  const cacheKey = searchCache.constructor.key('search', {
    q: opts.rawQuery,
    eq: effectiveQuery, // 包含改写后的查询，避免改写变化时返回旧缓存
    channel,
    max,
    sort,
    field,
    po: patentsOnly ? 1 : 0,
    personaSkill: opts.personaSkill?.slice(0, 30),
  });
  const cached = searchCache.get(cacheKey);
  if (cached && cached.papers?.length >= 12) { // 只有结果>=12篇才用缓存，太少说明上次搜索失败需重试
    console.log(`[search] cache hit for "${opts.rawQuery.slice(0, 30)}..." (${cached.papers.length} papers)`);
    return {
      ...cached,
      latencyMs: Date.now() - started,
      fromCache: true,
    };
  }
  if (cached && cached.papers?.length > 0) {
    console.log(`[search] cache has only ${cached.papers.length} papers, forcing re-search`);
    searchCache.delete(cacheKey);
  }

  const sourcesUsed = [];
  const buckets = [];

  if (!patentsOnly) {
  // 统一搜索策略：无论 database 还是 web 渠道，都执行完整的分层搜索
  // database 渠道会额外优先查询本地数据库，并将本地结果赋予更高权重
  
  // 第0层：本地数据库（PostgreSQL + SQLite）- database 渠道优先，web 渠道也查询作为保底
  if (channel === "database" || true) {
    // 1. 如果连接了 PostgreSQL (material_kb)，优先查询 DOI 记录（277万条）
    if (isPostgres()) {
      try {
        console.log("[search] Querying doi_records with:", effectiveQuery);
        const doiRows = await searchDoiRecords(effectiveQuery, max);
        console.log("[search] doi_records returned:", doiRows.length, "rows");
        if (doiRows.length > 0) {
          const doiPapers = doiRows.map(doiRecordToApiPaper);
          console.log("[search] doi_records papers:", doiPapers.length);
          sourcesUsed.push("material_kb_doi");
          buckets.push(doiPapers);
        }

        const fullPaperRows = await searchFullPapers(effectiveQuery, max);
        if (fullPaperRows.length > 0) {
          const fullPapers = fullPaperRows.map(materialKbRowToApiPaper);
          sourcesUsed.push("material_kb_papers");
          buckets.push(fullPapers);
        }
      } catch (e) {
        console.warn("[search] material_kb query failed", e?.message || e);
        sourcesUsed.push("material_kb_error");
      }
    }

    // 2. 查询应用本地 papers 表（SQLite）
    const localRows = await searchLocalPapers(effectiveQuery, Math.min(60, max + 20));
    if (localRows.length) {
      const localPapers = localRows.map(rowToApiPaper);
      sourcesUsed.push("local_sqlite");
      buckets.push(localPapers);
    }
  }

  // 第1-3层：网络来源（所有渠道都执行，确保结果充足）
  {
    const aq = buildArxivSearchQuery(effectiveQuery, field);
    const arxivSort = sort === "citations" ? "relevance" : mapArxivSort(sort);
    const doiHit = extractDoiCandidate(effectiveQuery);
    
    /** 
     * 网页渠道：分层并行搜索策略
     * 第0层（本地保底）：SQLite 本地数据库 - 始终查询作为保底
     * 第1层（快速核心源）：arXiv, Crossref, OpenAlex, Semantic Scholar - 15秒超时
     * 第2层（高质量源）：Scopus - 18秒超时
     * 第3层（补充源）：Patents, Europe PMC, MCP - 18秒超时，始终执行以获取专利和网页
     */
    
    // 第0层：本地数据库保底（始终执行，确保有结果返回）
    const localRows = await searchLocalPapers(effectiveQuery, Math.min(60, max + 20));
    if (localRows.length) {
      sourcesUsed.push("local_sqlite");
      buckets.push(localRows.map(rowToApiPaper));
    }
    
    // 第1层：快速核心源（通常响应快）
    const layer1Results = await raceWithTimeout([
      { name: 'arxiv', promise: fetchArxiv({ searchQuery: aq, max: Math.min(70, max + 25), sort: arxivSort }) },
      { name: 'crossref', promise: fetchCrossrefWorks(effectiveQuery, Math.min(50, max + 20)) },
      { name: 'openalex', promise: fetchOpenAlexWorks(effectiveQuery, Math.min(50, max + 20)) },
      { name: 'semantic_scholar', promise: fetchSemanticScholarWorks(effectiveQuery, Math.min(50, max + 20)) },
    ], 18000); // 18秒超时
    
    let arxiv = [], crossSearch = [], oaSearch = [], semanticSearch = [];
    
    for (const r of layer1Results) {
      if (r.status === 'fulfilled') {
        switch (r.name) {
          case 'arxiv': arxiv = r.value; sourcesUsed.push('arxiv'); break;
          case 'crossref': crossSearch = r.value; sourcesUsed.push('crossref'); break;
          case 'openalex': oaSearch = r.value; sourcesUsed.push('openalex'); break;
          case 'semantic_scholar': semanticSearch = r.value; if (r.value.length) sourcesUsed.push('semantic_scholar'); break;
        }
      } else {
        console.warn(`[search] ${r.name} timeout/failed:`, r.reason);
        sourcesUsed.push(`${r.name}_error`);
      }
    }
    
    // 第2层：高质量源 Scopus（通常较慢但质量高）
    const scopusResult = await raceWithTimeout([
      { name: 'scopus', promise: fetchScopusWorks(effectiveQuery, Math.min(60, max + 30)) }
    ], 18000); // 18秒超时
    
    let scopusSearch = [];
    const scopusR = scopusResult[0];
    if (scopusR?.status === 'fulfilled') {
      scopusSearch = scopusR.value;
      if (scopusSearch.length) sourcesUsed.push('scopus');
    } else {
      console.warn('[search] scopus timeout/failed:', scopusR?.reason);
      sourcesUsed.push('scopus_error');
    }
    
    // 合并前两层结果
    let crossBatches = [crossSearch, oaSearch, scopusSearch, semanticSearch];
    
    // DOI精确查询（如果适用）
    if (doiHit) {
      try {
        const byDoi = await fetchCrossrefWorkByDoi(doiHit);
        if (byDoi.length) {
          crossBatches.unshift(byDoi);
          sourcesUsed.push("crossref_doi");
        }
      } catch (e) {
        console.warn('[search] doi fetch failed:', e?.message);
      }
    }
    
    // 第3层：始终获取专利、网页等非文献资源（与文献合并呈现）
    let patentSearch = [], europeSearch = [], webResults = { papers: [], note: "skipped", toolName: null };
    
    const supplementalTasks = [];

    supplementalTasks.push({
      name: "europepmc",
      promise: fetchEuropePmcWorks(effectiveQuery, 35),
    });

    // 专利 + 全网网页：默认合并（useMcpWeb 为 false 时跳过外呼，便于离线/合规场景）
    if (useMcpWeb !== false) {
      // OpenAlex 专利 API（独立调用，结果标记为 openalex_patent）
      supplementalTasks.push({
        name: "openalex_patents",
        promise: fetchOpenAlexPatents(effectiveQuery, 35),
      });
      supplementalTasks.push({
        name: "patents",
        promise: fetchPatentPapers(effectiveQuery, 35),
      });
      supplementalTasks.push({
        name: "web",
        promise: (async () => {
          if (getDataifyWebSearchConfig()) {
            try {
              const dr = await fetchDataifyWebPapers(effectiveQuery, 35);
              if (dr.papers?.length) return dr;
            } catch (e) {
              console.warn("[search] dataify_web:", e?.message);
            }
          }
          if (isMcpUsable()) return fetchMcpWebPapers(effectiveQuery, 35);
          return fetchDuckDuckGoSearch(effectiveQuery, 35);
        })(),
      });
    }
    
    const supplementalResults = await raceWithTimeout(supplementalTasks, 18000);
    
    for (const r of supplementalResults) {
      if (r.status === 'fulfilled') {
        switch (r.name) {
          case "openalex_patents":
            const oaPatVal = r.value;
            const oaPatPapers = Array.isArray(oaPatVal) ? oaPatVal : [];
            if (oaPatPapers.length) {
              patentSearch = [...patentSearch, ...oaPatPapers];
              sourcesUsed.push("openalex_patents");
            }
            break;
          case "patents":
            const ptVal = r.value;
            const patPapers = ptVal && typeof ptVal === "object" ? (ptVal.papers ?? []) : [];
            patentSearch = Array.isArray(patPapers) ? patPapers : (Array.isArray(ptVal) ? ptVal : []);
            if (patentSearch.length) {
              const ptTool = (ptVal && ptVal.toolName) || "patents";
              sourcesUsed.push(ptTool ? `patents:${ptTool}` : "patents");
            }
            break;
          case 'europepmc': 
            europeSearch = r.value; 
            if (europeSearch.length) sourcesUsed.push('europepmc'); 
            break;
          case 'web':
            const wv = r.value;
            webResults = wv && typeof wv === "object"
              ? { papers: wv.papers ?? [], note: wv.note, toolName: wv.toolName }
              : { papers: [], note: "skipped", toolName: null };
            if (webResults.papers?.length) {
              sourcesUsed.push(webResults.toolName ? `web:${webResults.toolName}` : "web");
            }
            break;
        }
      } else {
        console.warn(`[search] ${r.name} timeout/failed:`, r.reason);
        sourcesUsed.push(`${r.name}_error`);
      }
    }

    /** Scopus 放最后传入 mergeDedupe，同 DOI 时优先保留爱思唯尔题录（scoreSource 已最高） */
    buckets.push(arxiv, mergeDedupe(crossBatches));
    if (patentSearch.length) buckets.push(patentSearch);
    if (europeSearch.length) buckets.push(europeSearch);
    if (webResults.papers?.length) buckets.push(webResults.papers);
    let interim = mergeDedupe(buckets);
    
    // 如果外部源结果不足，再补充本地数据库（第0层已查询过，这里只在仍不足时追加）
    if (interim.length < max) {
      const localRows = await searchLocalPapers(effectiveQuery, max - interim.length + 15);
      if (localRows.length) {
        sourcesUsed.push("local_sqlite_supplement");
        buckets.push(localRows.map(rowToApiPaper));
      }
    }
  }
  } else {
    /** 仅专利：不查论文索引、Europe PMC、网页 SERP；只并联 OpenAlex 专利 + DDG/MCP 专利 */
    let patentSearchOnly = [];
    const poTasks = [];
    if (useMcpWeb !== false) {
      poTasks.push({
        name: "openalex_patents",
        promise: fetchOpenAlexPatents(effectiveQuery, 45),
      });
      poTasks.push({
        name: "patents",
        promise: fetchPatentPapers(effectiveQuery, 45),
      });
    }
    const poResults = await raceWithTimeout(poTasks, 25000);
    for (const r of poResults) {
      if (r.status === "fulfilled") {
        switch (r.name) {
          case "openalex_patents": {
            const oaPatVal = r.value;
            const oaPatPapers = Array.isArray(oaPatVal) ? oaPatVal : [];
            if (oaPatPapers.length) {
              patentSearchOnly = patentSearchOnly.concat(oaPatPapers);
              sourcesUsed.push("openalex_patents");
            }
            break;
          }
          case "patents": {
            const ptVal = r.value;
            const patPapers = ptVal && typeof ptVal === "object" ? (ptVal.papers ?? []) : [];
            const arr = Array.isArray(patPapers) ? patPapers : Array.isArray(ptVal) ? ptVal : [];
            if (arr.length) {
              patentSearchOnly = patentSearchOnly.concat(arr);
              const ptTool = ptVal && ptVal.toolName;
              sourcesUsed.push(ptTool ? `patents:${ptTool}` : "patents");
            }
            break;
          }
          default:
            break;
        }
      } else {
        console.warn(`[search] ${r.name} timeout/failed:`, r.reason);
        sourcesUsed.push(`${r.name}_error`);
      }
    }
    if (patentSearchOnly.length) buckets.push(patentSearchOnly);
    sourcesUsed.push("mode:patents_only");
    if (useMcpWeb === false) sourcesUsed.push("patents_only_skipped_mcp_web");
  }

  let merged = mergeDedupe(buckets);
  const beforeFilter = merged.length;
  merged = dropZeroRelevanceByTokens(merged, opts.rawQuery, effectiveQuery, opts.preferenceKeywords);
  if (merged.length > 0 && merged.length < beforeFilter) {
    sourcesUsed.push("relevance_token_drop");
  }
  const mergedTokens = extractQueryTokensMerged(opts.rawQuery, effectiveQuery, opts.preferenceKeywords);
  const beforeStrict = merged.length;
  merged = strictRecommendFilterAndRank(merged, mergedTokens, max, {
    preferenceCount: normalizePreferenceKeywords(opts.preferenceKeywords).length,
  });
  if (merged.length > 0 && merged.length < beforeStrict) {
    sourcesUsed.push("strict_recommend_filter");
  }
  merged = applySort(merged, sort);
  merged = merged.slice(0, max);
  if (patentsOnly) {
    merged = finalizePatentsOnlyRows(merged, max);
    sourcesUsed.push("patents_only_rows");
  }

  try {
    await upsertPapers(toIngestRows(merged), `batch:${channel}:${started}`);
  } catch (e) {
    console.error("[search] upsert failed", e);
  }

  const latencyMs = Date.now() - started;
  
  const result = {
    papers: merged,
    effectiveQuery,
    rewriteNote: rw.note,
    sourcesUsed,
    channel,
    sort,
    field,
    latencyMs,
    arxivSortUsed: sort === "citations" ? "relevance" : mapArxivSort(sort),
  };
  
  // 保存到缓存
  searchCache.set(cacheKey, result);
  console.log(`[search] cached result for "${opts.rawQuery.slice(0, 30)}..." (${latencyMs}ms)`);
  
  return result;
}
