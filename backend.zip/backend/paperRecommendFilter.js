/**
 * 论文推荐：主题相关性、去重与期刊/引用质量排序（Scopus 等索引来源加权，近似「高质量期刊」优先）。
 * 与 searchService 中的 token 抽取配合使用。
 */

/** @param {object} p */
export function sourceTier(p) {
  const s = String(p.source ?? "");
  if (s === "scopus") return 100;
  if (s === "local") return 45;
  if (s === "semantic_scholar") return 55;
  if (s === "openalex_patent") return 44;
  if (s === "europepmc") return 41;
  if (s === "openalex") return 38;
  if (s === "arxiv") return 18;
  if (s === "mcp_web") return 35;
  if (s === "ddg_web") return 32;
  if (s === "ddg_patent") return 40;
  return 25;
}

/**
 * 期刊/渠道质量加分：正式出版物名称、高被引等（无法可靠判定 SCI 时用工学启发式）。
 * @param {object} p
 */
export function venueImpactBoost(p) {
  const venue = String(p.venue ?? "").trim();
  let bonus = 0;
  if (venue && venue !== "Scopus" && venue !== "OpenAlex") {
    bonus += 12;
    if (/^patent\b|^patent ·/i.test(venue)) bonus += 10;
    const v = venue.toLowerCase();
    if (
      /\bjournal\b|\bletters\b|\bproceedings\b|\breview\b|\bnature\b|\bscience\b|\bcell\b|\bieee\b|\bacm\b|\bspringer\b|\belsevier\b|\bwiley\b|\bacs\b|\brsc\b|\btaylor\b/i.test(
        venue,
      )
    ) {
      bonus += 18;
    }
  }
  const cites = Number(p.isReferencedByCount);
  if (Number.isFinite(cites) && cites > 0) {
    bonus += Math.min(35, Math.log1p(cites) * 4.5);
  }
  return bonus;
}

/**
 * @param {object} p
 * @param {string[]} tokens
 */
export function relevanceRatio(p, tokens) {
  const raw = `${p.title || ""} ${p.summary || p.abstract || ""}`;
  const blob = raw.toLowerCase();
  let hits = 0;
  for (const t of tokens) {
    const s = String(t);
    if (/[\u4e00-\u9fff]/.test(s)) {
      if (raw.includes(s)) hits++;
    } else {
      const tl = s.toLowerCase();
      if (tl.length >= 2 && blob.includes(tl)) hits++;
    }
  }
  const denom = Math.max(1, tokens.length);
  return hits / denom;
}

/**
 * 严格剔除弱相关与近似重复标题；按来源层级 + 期刊/引用综合排序。
 * @param {object[]} papers
 * @param {string[]} mergedTokens 问题 + 检索式 + 用户喜好词
 * @param {number} max 上限（过滤后至多再截断到此）
 * @param {{ preferenceCount?: number }} [opts]
 */
export function strictRecommendFilterAndRank(papers, mergedTokens, max, opts) {
  const prefN = Math.max(0, Math.min(24, Number(opts?.preferenceCount) || 0));
  const list = Array.isArray(papers) ? [...papers] : [];
  const tokens = Array.isArray(mergedTokens) ? mergedTokens : [];
  let working = list;

  const norm = (t) =>
    String(t ?? "")
      .toLowerCase()
      .replace(/[^a-z0-9\u4e00-\u9fff]+/gi, " ")
      .trim()
      .slice(0, 140);

  // 结果太少时完全跳过严格过滤，直接排序返回
  if (list.length <= 25) {
    const scored = list.map((p) => {
      const rel = tokens.length ? relevanceRatio(p, tokens) * 80 : 40;
      const tier = sourceTier(p);
      const ven = venueImpactBoost(p);
      return { p, score: tier + ven + rel, nt: norm(p.title) };
    });
    const bestByNormTitle = new Map();
    for (const x of scored) {
      const k = x.nt || `_id:${String(x.p.paper_id ?? x.p.doi ?? "")}`;
      const prev = bestByNormTitle.get(k);
      if (!prev || x.score > prev.score) bestByNormTitle.set(k, x);
    }
    const mergedRanked = [...bestByNormTitle.values()].sort(
      (a, b) => b.score - a.score || String(a.p.title).localeCompare(String(b.p.title)),
    );
    return mergedRanked.map((x) => x.p);
  }

  // 中文查询检测：如果token全是中文，跳过严格相关性过滤（英文论文不会命中中文token）
  const hasChineseToken = tokens.some(t => /[\u4e00-\u9fff]/.test(String(t)));
  const hasEnglishToken = tokens.some(t => /[a-zA-Z]/.test(String(t)));
  const isChineseOnlyQuery = hasChineseToken && !hasEnglishToken;

  /** 有喜好词时略提高门槛，使条目更贴问题与偏好 */
  // 大幅放宽条件：确保返回足够的结果（目标30+条）
  const minRatio = prefN >= 2 ? 0.08 : prefN >= 1 ? 0.06 : 0.05;
  const minHits = tokens.length >= 6 ? 1 : 1;
  const fallbackRatio = prefN >= 2 ? 0.04 : 0.03;
  const minTierFallback = 25;  // 让更多来源通过（包括web、patent等）

  if (tokens.length >= 2 && !isChineseOnlyQuery) {
    working = list.filter((p) => {
      const src = String(p.source ?? "");
      if (src === "ddg_patent" || src === "openalex_patent") return true;
      const r = relevanceRatio(p, tokens);
      const rawText = `${p.title || ""} ${p.summary || p.abstract || ""}`;
      const blob = rawText.toLowerCase();
      let hitCount = 0;
      for (const t of tokens) {
        const s = String(t);
        if (/[\u4e00-\u9fff]/.test(s)) {
          if (rawText.includes(s)) hitCount++;
        } else {
          const tl = s.toLowerCase();
          if (tl.length >= 2 && blob.includes(tl)) hitCount++;
        }
      }
      if (hitCount >= minHits) return true;
      if (r >= minRatio) return true;
      return false;
    });
    if (working.length < Math.min(2, list.length)) {
      working = list.filter(
        (p) => relevanceRatio(p, tokens) >= fallbackRatio || sourceTier(p) >= minTierFallback,
      );
    }
    if (working.length === 0) working = list;
  }

  const scored = working.map((p) => {
    const rel = tokens.length ? relevanceRatio(p, tokens) * 80 : 40;
    const tier = sourceTier(p);
    const ven = venueImpactBoost(p);
    const score = tier + ven + rel;
    return { p, score, nt: norm(p.title) };
  });

  const bestByNormTitle = new Map();
  for (const x of scored) {
    const k = x.nt || `_id:${String(x.p.paper_id ?? x.p.doi ?? "")}`;
    const prev = bestByNormTitle.get(k);
    if (!prev || x.score > prev.score) bestByNormTitle.set(k, x);
  }

  const mergedRanked = [...bestByNormTitle.values()].sort(
    (a, b) => b.score - a.score || String(a.p.title).localeCompare(String(b.p.title)),
  );

  const cap = Math.min(180, Math.max(15, max + 30));
  return mergedRanked.slice(0, cap).map((x) => x.p);
}
