import dotenv from "dotenv";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_ENV_PATH = path.resolve(__dirname, "..", ".env");
/** 无论从哪里启动 node，都先读项目根目录 .env，再读 cwd 下的 .env（可覆盖） */
dotenv.config({ path: ROOT_ENV_PATH });
dotenv.config();

// 调试：检查环境变量加载情况
const llmKey = process.env.LLM_API_KEY ?? process.env.OPENAI_API_KEY ?? "";
console.log("[env] LLM_API_KEY / OPENAI_API_KEY loaded:", llmKey ? "Yes (length: " + llmKey.length + ")" : "No");
console.log("[env] LLM key prefix:", llmKey ? llmKey.slice(0, 7) + "..." : "N/A");

const dbUrl = process.env.DATABASE_URL;
console.log("[env] DATABASE_URL loaded:", dbUrl ? "Yes" : "No");
console.log("[env] DATABASE_URL prefix:", dbUrl ? dbUrl.slice(0, 30) + "..." : "N/A");

import cors from "cors";
import {
  initDatabase,
  isDatabaseReady,
  isPostgres,
  logQuery,
  insertFeedback,
  logPdfDownload,
  countPdfDownloadsSince,
  getSqliteDb,
  pgPool,
} from "./db.js";
import { seedSimplePapersFromJson } from "./seedSimpleData.js";
import { seedDevAdminIfEnabled } from "./seedDevAdmin.js";
import { runPaperSearch } from "./searchService.js";
import { synthesizeFromPapers } from "./synthesize.js";
import { getPersonaSkill, listPersonas, normalizePersonaId } from "./personaSkills.js";
import { getMcpWebSearchConfig } from "./mcpWebSearch.js";
import { getDataifyWebSearchConfig } from "./dataifyWebSearch.js";
import { getElsevierScopusConfig } from "./scopusElsevier.js";
import { lookupUnpaywallOa } from "./unpaywallOa.js";
import { rateLimitHit } from "./rateLimit.js";
import { uploadMiddleware, extractDocumentText } from "./extract.js";
import { handleLogin, handleMe, handleRegister, resolveUserIdFromRequest } from "./auth.js";
import {
  saveUserSkill,
  getUserSkill,
  recordDownloadedPaper,
  getUserDownloadedPapers,
  recordAnswerFeedback,
  getUserAnswerFeedback,
  updateUserInfo,
  listAllUsers,
  getDatabaseStats,
  getSearchHistory,
} from "./db.js";
import {
  extractChartSpecWithLlm,
  normalizeChartSpec,
  renderChartPngWithMatplotlib,
  buildFallbackChartSpecFromAbstracts,
} from "./paperChart.js";
import { augmentQueryWithMatsci, isMatsciAugmentConfigured } from "./matsciNerAugment.js";
import { GStack, quickGStack } from "./gstack.js";
import { GBrain, getGBrain } from "./gbrain.js";
import { searchCache, rewriteCache } from "./cache.js";

const PORT = (() => {
  const n = Number.parseInt(String(process.env.PORT ?? "").trim(), 10);
  return Number.isFinite(n) && n > 0 && n < 65536 ? n : 8787;
})();

// 初始化 GStack 和 GBrain
const gstack = new GStack();
const gbrain = getGBrain();

console.log("[GStack] 图融合引擎已初始化");
console.log("[GBrain] 知识图谱大脑已初始化");

// 启动时清除缓存（避免旧缓存数据污染）
searchCache.clear();
rewriteCache.clear();
console.log("[cache] 搜索缓存和改写缓存已清除");

function clientIp(req) {
  const xf = req.headers["x-forwarded-for"];
  if (typeof xf === "string" && xf.length) return xf.split(",")[0].trim();
  return req.socket?.remoteAddress || "local";
}

const QUERY_SYNTAX_HELP = `## 查询语法（摘录）

- **默认**：分词式关键词检索；若启用 LLM，会将任意语言（含中文整句）理解为研究意图并输出**单行英文关键词**再检索。服务端使用 **OpenAI 兼容** Chat Completions（默认 URL 可为 DeepSeek 官方或其它网关），环境变量 \`LLM_CHAT_COMPLETIONS_URL\`、\`LLM_API_KEY\`（或 \`OPENAI_API_KEY\`）与侧栏 Key 一致即可；模型名见 \`LLM_MODEL\` / \`defaultModel()\`。
- **自建数据库**：在 \`.env\` 设置 \`DATABASE_URL=postgresql://用户:密码@主机:5432/数据库名\` 后重启 API，应用会使用 **PostgreSQL** 中的 \`papers\` 等表（启动时自动 \`CREATE TABLE IF NOT EXISTS\`）。\`papers\` 字段与 SQLite 一致：\`paper_id, doi, title, abstract, year, venue, oa_status, source_batch, created_at, updated_at, arxiv_id, authors_json, abs_url, pdf_url\`。**数据库优先**渠道仅检索该表。未设置 \`DATABASE_URL\` 时使用项目内 **SQLite**（\`backend/data/app.sqlite\`）。\`POST /api/v1/search\` 的 JSON \`max\` 为**上限**（数据库默认约 48、上限 80；网页默认约 28、上限 55）；实际条数由**与问题及用户喜好词的相关度**过滤决定，弱相关会被剔除，故可多可少。可选 \`preferenceKeywords\` 字符串数组（与账号侧栏「收藏关键词」同源）以收紧命中。
- **可选演示种子**：仅当 \`SIMPLE_SEED=1\` 时，启动会从 \`backend/data/simple-papers.json\`（若存在）及 \`simple datas/*.json\` 合并导入；默认**不**导入。检索词含 DOI 时本地按 DOI 列匹配；「网页」渠道会合并 Crossref、**OpenAlex** 与（若配置 \`ELSEVIER_API_KEY\`）**Scopus 元数据检索**。可设 \`OPENALEX_CONTACT_EMAIL\`。
- **网页全网（Dataify，可选）**：在 \`.env\` 设置 \`DATAIFY_API_KEY\` 后，「网页」渠道会**优先**调用 Dataify 搜索引擎 API 拉取链接；无结果或失败时再回退到 MCP Brave 或 DuckDuckGo。路径与鉴权可用 \`DATAIFY_API_BASE\`、\`DATAIFY_WEB_PATH\`、\`DATAIFY_AUTH_PREFIX\` 等与控制台文档对齐。
- **MCP 网页搜索（可选）**：配置 \`MCP_WEB_COMMAND\`、\`MCP_WEB_ARGS_JSON\` 后，在无 Dataify 结果时作为网页来源之一。详见 \`GET /api/v1/mcp/status\`。请求体 \`"useMcpWeb": false\` 将**跳过**专利与全网网页（DDG/Dataify/MCP）外呼，其它检索不变。
- **网页渠道与爱思唯尔（Elsevier）**：选择「网页」检索时**必须**在 \`.env\` 配置 \`ELSEVIER_API_KEY\`（Scopus Search API，https://dev.elsevier.com 申请）；未配置将返回错误而无法检索。合并结果中 **Scopus 题录优先展示、去重时优先保留**。同一请求内还会 **并行** 拉取：arXiv、Crossref、OpenAlex、Semantic Scholar、**Europe PMC**（生物医学等开放索引）、**专利补充**（Brave/MCP 或 DuckDuckGo「检索词 + patent」；网页渠道**始终**请求，与是否合并普通 MCP 网页无关）、以及（若配置 \`DATAIFY_API_KEY\` 或 \`MCP_WEB_*\`）**全网网页搜索结果**，再统一去重与排序。仅查自建库请用「数据库优先」渠道。
- **文献综述**：已配置 LLM Key 时，\`POST /api/v1/search\` 默认在检索完成后基于返回文献的**摘要摘录**再调用一次模型，生成中文综述；引用处须带 \`(DOI: …)\` 或 \`(arXiv: …)\`（由模型按摘录中的标识书写）。**若用户问题或摘录涉及工艺链、工序、产线/SOP 等**，综述中的「方案说明」会要求包含 **\`### 工序流程\`** 有序步骤，且与响应 JSON 字段 \`synthesisPlan.steps\` 对齐。请求体 \`"includeSynthesis": false\` 可关闭以节省 token。**双模型共识**：请求头 \`X-Model-B\` 或 JSON \`"modelB": "…"\`（或 \`LLM_MODEL_B\`）指定第二模型时，主模型与模型 B **并行**生成综述后，再调用一次主 Key 的模型仅保留两份综述的**共享部分**（见响应 \`synthesisModels\` 与 \`synthesisNote\`）。**三密钥 A/B 写、C 仲裁**：在服务端 \`.env\` 同时配置 \`SYNTHESIS_API_KEY_A\`、\`SYNTHESIS_API_KEY_B\`、\`SYNTHESIS_API_KEY_C\` 时，综述由 A、B 各用独立 Key 并行生成，再由 C 的 Key 调用模型输出**唯一终稿**（\`synthesisModels.mode\` 为 \`tri_arbitration\`）；可选 \`SYNTHESIS_MODEL_A\` / \`_B\` / \`_C\`、\`SYNTHESIS_CHAT_URL_A\` / \`_B\` / \`_C\` 指定模型名与兼容接口 URL（未设则沿用 \`LLM_CHAT_COMPLETIONS_URL\` 与默认模型名）。
- **身份 / 用途（Skill）**：请求头 \`X-Persona\` 或 JSON 体 \`persona\` 填内置 id（见 \`GET /api/v1/personas\`）。服务端在**检索式 LLM 改写**与**文献综述**前会先拼接对应 Skill 再调用模型；未传时默认为 \`researcher\`。
- **上传**：支持 PDF、Markdown、TXT、Word（.docx / .doc），解析后的正文会并入检索上下文（见 \`POST /api/v1/extract\`）。
- **无命中扩检**：\`POST /api/v1/search\` 在首次检索返回 **0 条**文献时，会自动再跑一轮放宽检索（arXiv 字段固定为全文综合 \`all\`、关闭检索式 LLM 改写或附带扩检提示再改写），仍无结果时会在 \`rewriteNote\` 中带 \`expand2:still_zero\`。
- **材料 MatSciBERT（身份 skill）**：侧栏身份选 **「材料 MatSciBERT（NER）」**（id: \`materials_matsci\`）时，服务端会用本机 Python 加载 \`MATSCI_PIPELINE_ROOT\`（默认 \`E:\\15w\`）下的 \`pipeline.py\` + MatSciBERT NER，在用户检索句后追加材料实体短语，再进入 LLM 检索式改写与多源检索。需已安装与 \`E:\\15w\` 管线相同的 PyTorch / transformers / nltk 等；可用 \`MATSCI_PYTHON\` 指定解释器，\`MATSCI_NER_DISABLE=1\` 关闭。
- **短语**：用英文双引号包裹，例如 \`"deep learning"\`。
- **作者**：\`author:Einstein\` 或 \`author:"Yann LeCun"\`（映射 arXiv \`au:\`）。
- **年份**：\`year:2023\`（映射 arXiv 提交时间区间）。

更多字段组合可在后续版本扩展。`;

const app = express();
app.use(cors({ origin: true }));
app.use(express.json({ limit: "4mb" }));

// ==================== 管理端静态文件 ====================
const adminDir = path.resolve(__dirname, "..", "admin");
const adminExists = fs.existsSync(adminDir);
if (adminExists) {
  app.use("/admin", express.static(adminDir));
  console.log(`[admin] 管理端静态文件已挂载: /admin → ${adminDir}`);
} else {
  console.warn(`[admin] 管理端目录不存在: ${adminDir}`);
}

// 数据库就绪检查中间件（仅对 /api/ 路由生效，不影响静态文件和管理端）
app.use("/api", (req, res, next) => {
  if (!isDatabaseReady()) {
    console.error("[db] 未初始化");
    return res.status(503).json({ error: "数据库尚未就绪" });
  }
  next();
});

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "quantum-pinnacle",
    version: "1",
    /** 前端可据此判断当前 8787 是否为带图表路由的新版 API */
    features: {
      chartFromPapers: true,
      matsciNerAugment: isMatsciAugmentConfigured(),
      deepPaperMine: true,
    },
  });
});

app.post("/api/v1/auth/register", async (req, res) => {
  await handleRegister(req, res);
});

app.post("/api/v1/auth/login", async (req, res) => {
  await handleLogin(req, res);
});

app.get("/api/v1/auth/me", async (req, res) => {
  await handleMe(req, res);
});

// ==================== 用户特征Skill API ====================

/** 获取当前用户的Skill */
app.get("/api/v1/user/skill", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    if (!userId || userId === "anonymous") {
      return res.status(401).json({ error: "未登录" });
    }
    const skill = await getUserSkill(userId);
    if (!skill) {
      // 返回默认skill
      return res.json({
        personaId: "researcher",
        favoriteKeywords: [],
        downloadedPapers: [],
        answerFeedback: [],
      });
    }
    res.json({
      personaId: skill.persona_id,
      favoriteKeywords: skill.favorite_keywords ? JSON.parse(skill.favorite_keywords) : [],
      downloadedPapers: skill.downloaded_papers ? JSON.parse(skill.downloaded_papers) : [],
      answerFeedback: skill.answer_feedback ? JSON.parse(skill.answer_feedback) : [],
      updatedAt: skill.updated_at,
    });
  } catch (e) {
    console.error("[user/skill]", e);
    res.status(500).json({ error: "获取用户Skill失败" });
  }
});

/** 更新当前用户的Skill */
app.post("/api/v1/user/skill", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    if (!userId || userId === "anonymous") {
      return res.status(401).json({ error: "未登录" });
    }
    const { personaId, favoriteKeywords, downloadedPapers, answerFeedback } = req.body || {};
    await saveUserSkill(userId, {
      personaId,
      favoriteKeywords: favoriteKeywords ? JSON.stringify(favoriteKeywords) : null,
      downloadedPapers: downloadedPapers ? JSON.stringify(downloadedPapers) : null,
      answerFeedback: answerFeedback ? JSON.stringify(answerFeedback) : null,
    });
    res.json({ ok: true });
  } catch (e) {
    console.error("[user/skill]", e);
    res.status(500).json({ error: "保存用户Skill失败" });
  }
});

/** 记录用户下载的论文 */
app.post("/api/v1/user/downloaded-paper", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    if (!userId || userId === "anonymous") {
      return res.status(401).json({ error: "未登录" });
    }
    const { paperId, title, doi, source } = req.body || {};
    if (!paperId) return res.status(400).json({ error: "缺少paperId" });
    await recordDownloadedPaper(userId, { paperId, title, doi, source });
    res.json({ ok: true });
  } catch (e) {
    console.error("[user/downloaded-paper]", e);
    res.status(500).json({ error: "记录下载失败" });
  }
});

/** 获取用户下载的论文列表 */
app.get("/api/v1/user/downloaded-papers", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    if (!userId || userId === "anonymous") {
      return res.status(401).json({ error: "未登录" });
    }
    const limit = Math.min(100, Math.max(1, Number(req.query?.limit) || 50));
    const papers = await getUserDownloadedPapers(userId, limit);
    res.json({ papers });
  } catch (e) {
    console.error("[user/downloaded-papers]", e);
    res.status(500).json({ error: "获取下载列表失败" });
  }
});

/** 记录用户对答案的反馈 (good=1, bad=-1) */
app.post("/api/v1/user/answer-feedback", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    if (!userId || userId === "anonymous") {
      return res.status(401).json({ error: "未登录" });
    }
    const { query, answer, value } = req.body || {};
    if (value !== 1 && value !== -1) {
      return res.status(400).json({ error: "value须为1(good)或-1(bad)" });
    }
    await recordAnswerFeedback(userId, { query, answer, value });
    res.json({ ok: true });
  } catch (e) {
    console.error("[user/answer-feedback]", e);
    res.status(500).json({ error: "记录反馈失败" });
  }
});

/** 获取用户的答案反馈列表 */
app.get("/api/v1/user/answer-feedback", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    if (!userId || userId === "anonymous") {
      return res.status(401).json({ error: "未登录" });
    }
    const limit = Math.min(100, Math.max(1, Number(req.query?.limit) || 50));
    const feedback = await getUserAnswerFeedback(userId, limit);
    res.json({ feedback });
  } catch (e) {
    console.error("[user/answer-feedback]", e);
    res.status(500).json({ error: "获取反馈列表失败" });
  }
});

/** 更新用户信息（手机号、邮箱） */
app.post("/api/v1/user/info", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    if (!userId || userId === "anonymous") {
      return res.status(401).json({ error: "未登录" });
    }
    const { email, phone } = req.body || {};
    await updateUserInfo(userId, { email, phone });
    res.json({ ok: true });
  } catch (e) {
    console.error("[user/info]", e);
    res.status(500).json({ error: "更新用户信息失败" });
  }
});

/**
 * 从检索到的文献摘录用 LLM 抽取数值点（带 doi_x/doi_y），再用本机 Python+Matplotlib 渲染 PNG。
 * 请求体：{ papers: [...], hint?: string, synthesisMarkdown?: string }；需本机可执行 python 且已 pip install matplotlib。LLM Key 缺失时仍可能仅靠摘要后备出图。
 */
app.post("/api/v1/chart/from-papers", async (req, res) => {
  const ip = clientIp(req);
  if (!rateLimitHit(ip, { max: 20, windowMs: 60_000 })) {
    return res.status(429).json({ error: "请求过于频繁，请稍后再试" });
  }
  try {
    const papers = req.body?.papers;
    if (!Array.isArray(papers) || papers.length === 0) {
      return res.status(400).json({ error: "缺少 papers 数组" });
    }
    const hint = String(req.body?.hint ?? "").trim().slice(0, 500);
    const openaiApiKey = String(
      req.headers["x-openai-key"] ??
        req.headers["x-dashscope-key"] ??
        req.headers["x-deepseek-key"] ??
        "",
    )
      .trim()
      .slice(0, 512);
    const openaiModel = String(req.headers["x-openai-model"] ?? "")
      .trim()
      .slice(0, 96);
    const llmChatUrl = String(req.headers["x-llm-chat-url"] ?? "")
      .trim()
      .slice(0, 2048);

    const synthesisMd = String(req.body?.synthesisMarkdown ?? "").trim().slice(0, 8000);
    const extracted = await extractChartSpecWithLlm(papers, {
      apiKey: openaiApiKey,
      model: openaiModel,
      chatCompletionsUrl: llmChatUrl,
      userHint: hint,
      synthesisMarkdown: synthesisMd || undefined,
    });
    let spec = null;
    if (extracted.ok) spec = normalizeChartSpec(extracted.spec, papers);
    if (!spec) {
      const fb = buildFallbackChartSpecFromAbstracts(papers);
      if (fb) spec = normalizeChartSpec(fb, papers);
    }
    if (!spec) {
      return res.status(422).json({
        error:
          "未能形成可绘制的数值点（模型未返回有效 points，且摘要后备也未解析到「年份+百分数/eV」）。可换一批文献、在作图意图中写明坐标含义，或确认综述/摘要中含数字。",
        rawSpec: extracted.ok ? extracted.spec : null,
        llmError: extracted.ok ? undefined : extracted.error,
      });
    }
    const png = await renderChartPngWithMatplotlib(spec);
    if (!png.ok) {
      const { renderScatterChartSvg } = await import("./renderChartSvg.js");
      const svgStr = renderScatterChartSvg(spec);
      if (svgStr) {
        const svgBase64 = Buffer.from(svgStr, "utf8").toString("base64");
        return res.json({
          mime: "image/svg+xml",
          svgBase64,
          pngBase64: null,
          title: spec.title,
          spec,
          matplotlibError: png.error,
          note: "Python/matplotlib 不可用，已使用纯JS SVG渲染",
        });
      }
      return res.status(501).json({
        error: png.error,
        spec,
      });
    }
    return res.json({
      mime: "image/png",
      pngBase64: png.pngBase64,
      svgBase64: null,
      title: spec.title,
      spec,
      matplotlibStderr: png.stderr || undefined,
    });
  } catch (e) {
    console.error("[chart/from-papers]", e);
    return res.status(500).json({ error: e?.message || "生成图表失败" });
  }
});

app.get("/api/v1/db/info", (_req, res) => {
  res.json({
    backend: isPostgres() ? "postgresql" : "sqlite",
    simpleSeedOnStartup: String(process.env.SIMPLE_SEED ?? "").trim() === "1",
  });
});

app.get("/api/v1/help/query-syntax", (_req, res) => {
  res.json({ markdown: QUERY_SYNTAX_HELP });
});

app.get("/api/v1/personas", (_req, res) => {
  res.json({ personas: listPersonas() });
});

/** Unpaywall：按 DOI 查合法 OA PDF 直链（须 .env 配置 UNPAYWALL_EMAIL 或 OPENALEX_CONTACT_EMAIL） */
app.get("/api/v1/papers/unpaywall-oa", async (req, res) => {
  const ip = clientIp(req);
  if (!rateLimitHit(ip, { max: 45, windowMs: 60_000 })) {
    return res.status(429).json({ error: "请求过于频繁，请稍后再试" });
  }
  const doi = String(req.query?.doi ?? "").trim();
  if (!doi) return res.status(400).json({ error: "缺少查询参数 doi" });
  try {
    const r = await lookupUnpaywallOa(doi);
    if (!r.ok) {
      return res.status(400).json({ error: r.error || "查询失败" });
    }
    return res.json(r);
  } catch (e) {
    console.error("[unpaywall-oa]", e);
    return res.status(500).json({ error: e?.message || "查询失败" });
  }
});

app.get("/api/v1/mcp/status", (_req, res) => {
  const c = getMcpWebSearchConfig();
  const df = getDataifyWebSearchConfig();
  const sc = getElsevierScopusConfig();
  res.json({
    mcpWebConfigured: Boolean(c),
    dataifyWebConfigured: Boolean(df),
    scopusElsevierConfigured: Boolean(sc),
    scopusInstTokenConfigured: Boolean(sc?.instToken),
    maxResults: c?.maxResults ?? null,
    timeoutMs: c?.timeoutMs ?? null,
    envFile: ROOT_ENV_PATH,
    envFileExists: fs.existsSync(ROOT_ENV_PATH),
    hint: df
      ? "已配置 DATAIFY_API_KEY，网页渠道优先使用 Dataify 拉取网页结果；无结果时再尝试 MCP / DuckDuckGo。"
      : c
        ? "已配置 MCP_WEB_*，网页渠道检索会尝试合并 MCP 返回的链接条目。"
        : "未配置 Dataify / MCP：在项目根目录放置 .env（可参考 .env.example），可设置 DATAIFY_API_KEY（优先），或设置 MCP_WEB_COMMAND、MCP_WEB_ARGS_JSON 并填写 BRAVE_API_KEY；保存后重启 API。若 envFileExists 为 false，说明未找到该路径下的 .env。",
    scopusHint: sc
      ? "已配置 ELSEVIER_API_KEY（及可选 ELSEVIER_INST_TOKEN）。网页渠道检索**必须**使用 Scopus；合并结果中 Scopus 条目优先。"
      : "未配置 Scopus：**网页渠道将无法检索**（返回 ELSEVIER_REQUIRED）。请在 .env 设置 ELSEVIER_API_KEY（dev.elsevier.com 申请），保存并重启 API；机构环境可另设 ELSEVIER_INST_TOKEN。仅自建库请在前端选择「数据库优先」。",
    unpaywallOaConfigured: Boolean(
      String(process.env.UNPAYWALL_EMAIL ?? process.env.OPENALEX_CONTACT_EMAIL ?? "").trim(),
    ),
  });
});

app.post("/api/v1/pdf-click", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    const paperId = String(req.body?.paperId ?? "").slice(0, 256);
    if (!paperId) return res.status(400).json({ error: "缺少 paperId" });
    await logPdfDownload(userId, paperId);
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    const n = await countPdfDownloadsSince(userId, dayStart.getTime());
    res.json({ ok: true, downloadsToday: n, softLimit: 5 });
  } catch (e) {
    console.error("[pdf-click]", e);
    res.status(500).json({ error: "记录失败" });
  }
});

app.post("/api/v1/extract", (req, res, next) => {
  uploadMiddleware.single("file")(req, res, (err) => {
    if (err?.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ error: "文件过大（单文件上限 12MB）" });
    }
    if (err) {
      console.error("[extract] multer", err);
      return res.status(400).json({ error: err.message || "上传失败" });
    }
    next();
  });
}, async (req, res) => {
  const ip = clientIp(req);
  if (!rateLimitHit(ip)) {
    return res.status(429).json({ error: "请求过于频繁，请稍后再试" });
  }
  try {
    if (!req.file?.buffer) {
      return res.status(400).json({ error: "未收到文件（字段名须为 file）" });
    }
    const text = await extractDocumentText(req.file.buffer, req.file.originalname);
    res.json({
      filename: String(req.file.originalname || "file").slice(0, 512),
      charCount: text.length,
      preview: text.slice(0, 400),
      text,
    });
  } catch (e) {
    console.error("[extract]", e);
    res.status(500).json({ error: e?.message || "文件解析失败" });
  }
});

app.post("/api/v1/feedback", async (req, res) => {
  try {
    const messageId = String(req.body?.messageId ?? "");
    const value = Number(req.body?.value);
    const userId = await resolveUserIdFromRequest(req);
    const channel = String(req.body?.channel ?? "");
    if (!messageId) return res.status(400).json({ error: "缺少 messageId" });
    if (value !== 1 && value !== -1) return res.status(400).json({ error: "value 须为 1 或 -1" });
    await insertFeedback({ messageId, userId, channel, value });
    res.json({ ok: true });
  } catch (e) {
    console.error("[feedback]", e);
    res.status(500).json({ error: "反馈写入失败" });
  }
});

app.post("/api/v1/search", async (req, res) => {
  const ip = clientIp(req);
  if (!rateLimitHit(ip)) {
    console.warn("[rate-limit] deny", ip);
    return res.status(429).json({ error: "请求过于频繁，请稍后再试（S-5）" });
  }

  const t0 = Date.now();
  try {
    const rawQuery = String(req.body?.query ?? "").trim();
    const attachmentContext = String(req.body?.attachmentContext ?? "").trim().slice(0, 200_000);
    const mergedQuery = [rawQuery, attachmentContext ? `\n\n---- 上传文件摘录 ----\n${attachmentContext}` : ""]
      .filter(Boolean)
      .join("")
      .trim();
    if (!mergedQuery) {
      return res.status(400).json({ error: "请输入检索内容或上传可解析的文件" });
    }

    const channel = req.body?.channel === "web" ? "web" : "database";
    const field = req.body?.field === "ti" || req.body?.field === "abs" ? req.body.field : "all";
    const sortRaw = String(req.body?.sort ?? "relevance");
    const sort =
      sortRaw === "submittedDate" || sortRaw === "lastUpdatedDate" || sortRaw === "citations"
        ? sortRaw
        : "relevance";
    const maxCap = channel === "database" ? 200 : 150;
    const defaultMax = channel === "database" ? 80 : 50;
    const max = Math.min(maxCap, Math.max(1, Number(req.body?.max) || defaultMax));
    const userId = await resolveUserIdFromRequest(req);
    const useLlmRewrite = req.body?.useLlmRewrite !== false;
    const openaiApiKey = String(
      req.headers["x-openai-key"] ??
        req.headers["x-dashscope-key"] ??
        req.headers["x-deepseek-key"] ??
        "",
    )
      .trim()
      .slice(0, 512);
    const openaiModel = String(req.headers["x-openai-model"] ?? "")
      .trim()
      .slice(0, 96);
    /** 第二综述模型（与主模型并行生成后做共识合并）；也可用 JSON body.modelB 或环境变量 LLM_MODEL_B */
    const modelBClient = String(req.headers["x-model-b"] ?? req.body?.modelB ?? "")
      .trim()
      .slice(0, 96);
    const llmChatUrl = String(req.headers["x-llm-chat-url"] ?? "")
      .trim()
      .slice(0, 2048);
    const useMcpWeb = req.body?.useMcpWeb !== false;
    const patentsOnly = req.body?.patentsOnly === true;

    const personaId = normalizePersonaId(req.headers["x-persona"] ?? req.body?.persona);
    const personaSkill = getPersonaSkill(personaId);
    const personaLabel =
      listPersonas().find((p) => p.id === personaId)?.label ?? personaId;

    /** 用户喜好关键词（如账号侧栏收藏词），用于与问题一起收紧文献相关性 */
    let preferenceKeywords = [];
    const rawPk = req.body?.preferenceKeywords;
    if (Array.isArray(rawPk)) {
      preferenceKeywords = rawPk
        .map((x) => String(x ?? "").trim().slice(0, 96))
        .filter(Boolean)
        .slice(0, 24);
    }

    let searchMergedQuery = mergedQuery;
    if (personaId === "materials_matsci") {
      searchMergedQuery = await augmentQueryWithMatsci(mergedQuery);
    }

    let result = await runPaperSearch({
      rawQuery: searchMergedQuery,
      channel,
      field,
      sort,
      max,
      useLlmRewrite,
      useMcpWeb,
      patentsOnly,
      openaiApiKey: openaiApiKey || undefined,
      openaiModel: openaiModel || undefined,
      llmChatCompletionsUrl: llmChatUrl || undefined,
      personaSkill,
      preferenceKeywords: preferenceKeywords.length ? preferenceKeywords : undefined,
    });

    /** 首次 ≤5 命中时强制二次扩检：放宽 arXiv 至 all，增加 max */
    if (result.papers.length <= 5 && !patentsOnly) {
      const max2 = Math.min(maxCap, max + 20);
      const expandDuplicate =
        field === "all" && useLlmRewrite === false;
      const EXPAND_HINT =
        "\n\n[扩检：此前检索无文献命中，请仅输出更宽、仍与上述主题相关的单行英文检索式；避免过度拼接罕见词。]";
      const secondRaw = expandDuplicate ? searchMergedQuery + EXPAND_HINT : searchMergedQuery;
      const secondUseLlm = expandDuplicate ? true : false;
      const expandTag = expandDuplicate ? "expand2:field=all,llm_hint" : "expand2:field=all,rewrite=off";

      console.info(`[v1/search] only ${result.papers.length} hits — running expanded second pass`, {
        expandDuplicate,
        channel,
        field,
        max2,
      });

      const result2 = await runPaperSearch({
        rawQuery: secondRaw,
        channel,
        field: "all",
        sort,
        max: max2,
        useLlmRewrite: secondUseLlm,
        useMcpWeb,
        patentsOnly,
        openaiApiKey: openaiApiKey || undefined,
        openaiModel: openaiModel || undefined,
        llmChatCompletionsUrl: llmChatUrl || undefined,
        personaSkill,
        preferenceKeywords: preferenceKeywords.length ? preferenceKeywords : undefined,
      });

      if (result2.papers.length > 0) {
        result = {
          ...result2,
          field,
          rewriteNote: [result.rewriteNote, result2.rewriteNote, expandTag].filter(Boolean).join(" · "),
          latencyMs: (result.latencyMs ?? 0) + (result2.latencyMs ?? 0),
        };
      } else {
        result = {
          ...result,
          rewriteNote: [result.rewriteNote, result2.rewriteNote, expandTag, "expand2:still_zero"]
            .filter(Boolean)
            .join(" · "),
          latencyMs: (result.latencyMs ?? 0) + (result2.latencyMs ?? 0),
        };
      }
    }

    // ===== GStack 图融合 =====
    let gstackApplied = false;
    let gstackStats = null;
    if (!patentsOnly && result.papers.length > 0 && process.env.ENABLE_GSTACK !== "false") {
      try {
        console.log(`[v1/search] 应用GStack图融合: ${result.papers.length} 篇文献`);
        const fused = gstack.fuse(result.papers, rawQuery);
        gstackStats = gstack.getStats();
        // 如果融合后结果太少（<5且比原来少），保留原始结果
        if (fused.length < 5 && fused.length < result.papers.length) {
          console.log(`[v1/search] GStack融合后仅${fused.length}篇，保留原始${result.papers.length}篇`);
        } else {
          result.papers = fused;
        }
        gstackApplied = true;
        console.log(`[v1/search] GStack融合完成: ${result.papers.length} 篇, 社区数: ${gstackStats.communities}`);
      } catch (e) {
        console.error("[v1/search] GStack融合失败, 使用原始结果:", e.message);
      }
    }

    // ===== GBrain 记录查询 =====
    if (process.env.ENABLE_GBRAIN !== "false") {
      try {
        gbrain.recordQuery(rawQuery, result.papers);
      } catch (e) {
        console.error("[v1/search] GBrain记录查询失败:", e.message);
      }
    }

    const synthQuery = rawQuery.trim()
      ? rawQuery.slice(0, 6000)
      : attachmentContext
        ? `（用户未输入文字检索式，主要依据上传文件摘录）\n${attachmentContext.slice(0, 4000)}`
        : mergedQuery.slice(0, 6000);

    /** 客户端根据「不满意」反馈累积的综述输出偏好（纯文本，由前端生成） */
    const outputAvoidance = String(req.body?.outputAvoidance ?? "").trim().slice(0, 2000);

    const includeSynthesis = patentsOnly
      ? req.body?.includeSynthesis === true
      : req.body?.includeSynthesis !== false;
    let synthesis = null;
    let synthesisNote = null;
    let synthesisPlan = null;
    let synthesisPlanNote = null;
    let synthesisModelsOut = undefined;
    if (includeSynthesis && result.papers.length > 0) {
      const syn = await synthesizeFromPapers({
        userQuery: synthQuery,
        papers: result.papers,
        apiKey: openaiApiKey,
        model: openaiModel,
        modelB: modelBClient || undefined,
        chatCompletionsUrl: llmChatUrl,
        personaSkill,
        outputAvoidanceHint: outputAvoidance || undefined,
      });
      synthesis = syn.markdown;
      synthesisNote = syn.note;
      synthesisPlan = syn.plan ?? null;
      synthesisPlanNote = syn.planNote ?? null;
      synthesisModelsOut = syn.synthesisModels;
    }

    /** 下载 PDF → MinerU → 三模型关键词 → 深度综合（可选，请求体 deepMine） */
    let deepMine = null;
    let deepSynthesis = null;
    let deepSynthesisNote = null;
    const dm = req.body?.deepMine;
    const deepEnabled = dm === true || (dm && typeof dm === "object" && dm.enabled === true);
    if (deepEnabled && !patentsOnly && result.papers.length > 0) {
      try {
        if (typeof req.socket?.setTimeout === "function") req.socket.setTimeout(920_000);
        const { runDeepMinePipeline, synthesizeDeepFromMine } = await import("./deepPaperMine.js");
        const dmOpts = typeof dm === "object" && dm ? dm : {};
        deepMine = await runDeepMinePipeline({
          papers: result.papers,
          userQuery: synthQuery,
          apiKey: openaiApiKey,
          chatCompletionsUrl: llmChatUrl,
          maxPapers: dmOpts.maxPapers,
          maxPdfMb: dmOpts.maxPdfMb,
        });
        const runs = (deepMine?.papers ?? []).map((p) => ({
          title: p.title,
          doi: p.doi,
          mdPreview: p.mdPreview,
          keywords: (p.keywordModels ?? []).filter((k) => k.ok).map((k) => ({ model: k.model, data: k.data })),
        }));
        if (runs.some((r) => r.keywords.length)) {
          const ds = await synthesizeDeepFromMine({
            userQuery: synthQuery,
            runs,
            personaSkill,
            apiKey: openaiApiKey,
            model: openaiModel,
            chatUrl: llmChatUrl,
          });
          deepSynthesis = ds.markdown;
          deepSynthesisNote = ds.note;
        } else {
          deepSynthesisNote = "deep_synth:skipped_no_keywords";
        }
      } catch (e) {
        console.error("[v1/search] deepMine", e);
        deepMine = {
          enabled: true,
          note: `deep_mine:error:${String(e?.message || e).slice(0, 200)}`,
          papers: [],
        };
        deepSynthesisNote = "deep_synth:skipped_error";
      }
    }

    await logQuery({
      userId,
      query: rawQuery || "(仅上传文件)",
      filters: {
        channel,
        field,
        sort,
        patentsOnly,
        effectiveQuery: result.effectiveQuery,
        sources: result.sourcesUsed,
        attachmentChars: attachmentContext.length,
      },
      resultCount: result.papers.length,
      latencyMs: result.latencyMs,
    });

    res.json({
      papers: result.papers,
      effectiveQuery: result.effectiveQuery,
      rewriteNote: result.rewriteNote,
      sourcesUsed: result.sourcesUsed,
      channel: result.channel,
      sort: result.sort,
      field,
      patentsOnly,
      latencyMs: result.latencyMs,
      arxivSortUsed: result.arxivSortUsed,
      synthesis,
      synthesisNote,
      synthesisPlan,
      synthesisPlanNote,
      synthesisModels: synthesisModelsOut,
      persona: personaId,
      personaLabel,
      deepMine,
      deepSynthesis,
      deepSynthesisNote,
      // GStack & GBrain 信息
      gstack: gstackApplied ? {
        applied: true,
        stats: gstackStats,
      } : { applied: false },
      gbrain: {
        userSkill: process.env.ENABLE_GBRAIN !== "false" ? gbrain.generateUserSkill() : null,
      },
    });
  } catch (e) {
    const ms = Date.now() - t0;
    console.error("[v1/search] failed", { ms, message: e?.message, stack: e?.stack });
    if (e?.code === "ELSEVIER_REQUIRED") {
      return res.status(400).json({
        error: e.message,
        code: "ELSEVIER_REQUIRED",
        latencyMs: ms,
      });
    }
    res.status(500).json({ error: e?.message || "检索失败", latencyMs: ms });
  }
});

app.post("/api/search", async (req, res) => {
  const ip = clientIp(req);
  if (!rateLimitHit(ip)) return res.status(429).json({ error: "请求过于频繁" });
  try {
    const rawQuery = String(req.body?.query ?? "").trim();
    if (!rawQuery) return res.status(400).json({ error: "缺少 query" });
    const field = req.body?.field === "ti" || req.body?.field === "abs" ? req.body.field : "all";
    const max = Math.min(80, Math.max(1, Number(req.body?.max) || 40));
    const userId = await resolveUserIdFromRequest(req);
    const result = await runPaperSearch({
      rawQuery,
      channel: "web",
      field,
      sort: "relevance",
      max,
      useLlmRewrite: false,
    });
    await logQuery({
      userId,
      query: rawQuery,
      filters: { legacy: true, field, effectiveQuery: result.effectiveQuery },
      resultCount: result.papers.length,
      latencyMs: result.latencyMs,
    });
    res.json({ papers: result.papers, source: "arxiv", field });
  } catch (e) {
    console.error("[api/search]", e);
    if (e?.code === "ELSEVIER_REQUIRED") {
      return res.status(400).json({ error: e.message, code: "ELSEVIER_REQUIRED" });
    }
    res.status(500).json({ error: "服务器检索出错" });
  }
});

// ==================== GStack & GBrain API ====================

/** GStack 图融合 API */
app.post("/api/v1/gstack/fuse", async (req, res) => {
  try {
    const { papers, query, options } = req.body || {};
    if (!Array.isArray(papers) || papers.length === 0) {
      return res.status(400).json({ error: "缺少 papers 数组" });
    }
    
    const result = gstack.fuse(papers, query || "");
    const stats = gstack.getStats();
    
    res.json({
      fused: result,
      stats,
      algorithm: "gstack-pagerank-community",
    });
  } catch (e) {
    console.error("[gstack/fuse]", e);
    res.status(500).json({ error: "GStack融合失败" });
  }
});

/** GStack 快速融合 API */
app.post("/api/v1/gstack/quick-fuse", async (req, res) => {
  try {
    const { papers, query } = req.body || {};
    if (!Array.isArray(papers) || papers.length === 0) {
      return res.status(400).json({ error: "缺少 papers 数组" });
    }
    
    const result = quickGStack(papers, query || "");
    res.json({ fused: result, algorithm: "gstack-quick" });
  } catch (e) {
    console.error("[gstack/quick-fuse]", e);
    res.status(500).json({ error: "GStack快速融合失败" });
  }
});

/** GStack 统计信息 */
app.get("/api/v1/gstack/stats", (_req, res) => {
  res.json({
    stats: gstack.getStats(),
    options: gstack.options,
  });
});

/** GBrain 记录查询 */
app.post("/api/v1/gbrain/record-query", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    const { query, results } = req.body || {};
    
    gbrain.recordQuery(query || "", results || []);
    
    res.json({ ok: true, stats: gbrain.getStats() });
  } catch (e) {
    console.error("[gbrain/record-query]", e);
    res.status(500).json({ error: "记录查询失败" });
  }
});

/** GBrain 记录下载 */
app.post("/api/v1/gbrain/record-download", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    const { paper } = req.body || {};
    
    if (!paper) return res.status(400).json({ error: "缺少 paper" });
    
    gbrain.recordDownload(paper);
    
    res.json({ ok: true, stats: gbrain.getStats() });
  } catch (e) {
    console.error("[gbrain/record-download]", e);
    res.status(500).json({ error: "记录下载失败" });
  }
});

/** GBrain 记录反馈 */
app.post("/api/v1/gbrain/record-feedback", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    const { query, answer, value } = req.body || {};
    
    gbrain.recordFeedback(query || "", answer || "", value || 0);
    
    res.json({ ok: true, stats: gbrain.getStats() });
  } catch (e) {
    console.error("[gbrain/record-feedback]", e);
    res.status(500).json({ error: "记录反馈失败" });
  }
});

/** GBrain 获取用户画像 */
app.get("/api/v1/gbrain/profile", async (req, res) => {
  try {
    const userId = await resolveUserIdFromRequest(req);
    const profile = gbrain.getUserProfile();
    
    res.json({
      profile,
      userSkill: gbrain.generateUserSkill(),
    });
  } catch (e) {
    console.error("[gbrain/profile]", e);
    res.status(500).json({ error: "获取用户画像失败" });
  }
});

/** GBrain 获取推荐 */
app.get("/api/v1/gbrain/recommendations", async (req, res) => {
  try {
    const query = String(req.query?.query || "");
    const limit = Math.min(20, Math.max(1, Number(req.query?.limit) || 5));
    
    const recommendations = gbrain.getRecommendations(query, limit);
    
    res.json({ recommendations, query });
  } catch (e) {
    console.error("[gbrain/recommendations]", e);
    res.status(500).json({ error: "获取推荐失败" });
  }
});

/** GBrain 导出知识图谱 */
app.get("/api/v1/gbrain/graph", async (req, res) => {
  try {
    const graph = gbrain.exportGraph();
    
    res.json({
      graph,
      stats: gbrain.getStats(),
    });
  } catch (e) {
    console.error("[gbrain/graph]", e);
    res.status(500).json({ error: "导出图谱失败" });
  }
});

/** GBrain 统计信息 */
app.get("/api/v1/gbrain/stats", (_req, res) => {
  res.json({
    stats: gbrain.getStats(),
  });
});

// ==================== 管理端 API ====================

/** 管理端登录 */
app.post("/api/v1/auth/login", async (req, res) => {
  await handleLogin(req, res);
});

/** 仪表盘统计 */
app.get("/api/v1/admin/dashboard", async (_req, res) => {
  try {
    const db = await getSqliteDb();

    // 用户统计
    const usersResult = await db.all("SELECT COUNT(*) as total FROM users");
    const totalUsers = usersResult[0]?.total || 0;

    // 论文统计 - 使用PostgreSQL数据
    let doiCount = 0;
    let journalPaperCount = 0;
    if (pgPool) {
      try {
        const doiResult = await pgPool.query("SELECT COUNT(*) as count FROM doi_records");
        doiCount = parseInt(doiResult.rows[0].count) || 0;

        const jpResult = await pgPool.query("SELECT COUNT(*) as count FROM journal_papers");
        journalPaperCount = parseInt(jpResult.rows[0].count) || 0;
      } catch (pgErr) {
        console.error("[admin/dashboard] PostgreSQL query error:", pgErr.message);
      }
    }

    // 论文总数 = DOI数量 + 15万
    const totalPapers = doiCount + 150000;

    // 今日搜索
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const searchesResult = await db.all(
      "SELECT COUNT(*) as total FROM query_log WHERE ts >= ?",
      [todayStart.getTime()]
    );
    const todaySearches = searchesResult[0]?.total || 0;

    // 最近7天搜索趋势
    const weeklyTrend = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);

      const dayResult = await db.all(
        "SELECT COUNT(*) as count FROM query_log WHERE ts >= ? AND ts < ?",
        [date.getTime(), nextDate.getTime()]
      );
      weeklyTrend.push({
        date: date.toISOString().slice(0, 10),
        count: dayResult[0]?.count || 0,
      });
    }

    res.json({
      success: true,
      data: {
        users: { total: totalUsers, active: totalUsers },
        papers: {
          total: totalPapers,
          doi_count: doiCount,
          journal_papers: journalPaperCount,
        },
        today_searches: todaySearches,
        weekly_trend: weeklyTrend,
      },
    });
  } catch (e) {
    console.error("[admin/dashboard] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 用户列表 */
app.get("/api/v1/admin/users", async (req, res) => {
  try {
    const skip = Math.max(0, Number(req.query.skip) || 0);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 10));
    const search = String(req.query.search || "").trim();

    const db = await getSqliteDb();
    let sql = "SELECT id, username, created_at FROM users";
    let params = [];

    if (search) {
      sql += " WHERE username LIKE ?";
      params = [`%${search}%`];
    }

    const countResult = await db.all(
      `SELECT COUNT(*) as total FROM users ${search ? "WHERE username LIKE ?" : ""}`,
      search ? [`%${search}%`] : []
    );
    const total = countResult[0]?.total || 0;

    sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    params.push(limit, skip);

    const users = await db.all(sql, params);

    res.json({
      success: true,
      data: {
        users: users.map((u) => ({
          id: u.id,
          username: u.username,
          email: null,
          created_at: u.created_at,
          last_active: u.created_at,
          is_active: true,
        })),
        total,
      },
    });
  } catch (e) {
    console.error("[admin/users] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 文献数据库列表 - 使用PostgreSQL aizhishi_papers表 */
app.get("/api/v1/admin/pdfs", async (req, res) => {
  try {
    const skip = Math.max(0, Number(req.query.skip) || 0);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 10));
    const search = String(req.query.search || "").trim();

    let pdfs = [];
    let total = 0;

    if (pgPool) {
      try {
        // 查询总数
        let countSql = "SELECT COUNT(*) as total FROM aizhishi_papers";
        let countParams = [];
        if (search) {
          countSql += " WHERE title ILIKE $1 OR material_name ILIKE $1";
          countParams = [`%${search}%`];
        }
        const countResult = await pgPool.query(countSql, countParams);
        total = parseInt(countResult.rows[0].total) || 0;

        // 查询数据 - 包含11个要素字段
        let sql = `SELECT paper_id, doi, title, material_name, symmetry_phase, structure_descriptor, 
                   properties, applications, synthesis_method, characterization_method, 
                   year, venue, first_author 
                   FROM aizhishi_papers`;
        let params = [];
        if (search) {
          sql += " WHERE title ILIKE $1 OR material_name ILIKE $1";
          params = [`%${search}%`];
        }
        sql += " ORDER BY year DESC NULLS LAST LIMIT $" + (params.length + 1) + " OFFSET $" + (params.length + 2);
        params.push(limit, skip);

        const result = await pgPool.query(sql, params);
        pdfs = result.rows;
      } catch (pgErr) {
        console.error("[admin/pdfs] PostgreSQL error:", pgErr.message);
      }
    }

    res.json({
      success: true,
      data: {
        pdfs: pdfs.map((p) => ({
          id: p.paper_id,
          doi: p.doi,
          title: p.title,
          material_name: p.material_name || "",
          material_type: p.symmetry_phase || "",
          application_field: p.structure_descriptor || "",
          performance_metrics: p.properties || "",
          preparation_method: p.applications || "",
          test_conditions: p.synthesis_method || "",
          data_source: p.characterization_method || "",
          year: p.year,
          journal: p.venue || "",
          first_author: p.first_author || "",
        })),
        total,
      },
    });
  } catch (e) {
    console.error("[admin/pdfs] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 获取单个文献详情 */
app.get("/api/v1/admin/pdfs/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!pgPool) {
      return res.status(500).json({ success: false, message: "PostgreSQL not available" });
    }
    
    const result = await pgPool.query(
      "SELECT * FROM aizhishi_papers WHERE paper_id = $1",
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: "Paper not found" });
    }
    
    const p = result.rows[0];
    res.json({
      success: true,
      data: {
        id: p.paper_id,
        doi: p.doi,
        title: p.title,
        abstract: p.abstract,
        material_name: p.material_name || "",
        material_type: p.symmetry_phase || "",
        application_field: p.structure_descriptor || "",
        performance_metrics: p.properties || "",
        preparation_method: p.applications || "",
        test_conditions: p.synthesis_method || "",
        data_source: p.characterization_method || "",
        year: p.year,
        journal: p.venue || "",
        first_author: p.first_author || "",
        corresponding_author: p.corresponding_author || "",
        authors_json: p.authors_json,
        arxiv_id: p.arxiv_id,
        pdf_url: p.pdf_url,
        abs_url: p.abs_url,
        oa_status: p.oa_status,
        category: p.category,
      }
    });
  } catch (e) {
    console.error("[admin/pdfs/:id] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 删除文献 */
app.delete("/api/v1/admin/pdfs/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!pgPool) {
      return res.status(500).json({ success: false, message: "PostgreSQL not available" });
    }
    
    await pgPool.query("DELETE FROM aizhishi_papers WHERE paper_id = $1", [id]);
    
    res.json({
      success: true,
      message: "Paper deleted successfully"
    });
  } catch (e) {
    console.error("[admin/pdfs/:id delete] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** DOI管理列表 - 使用PostgreSQL doi_records表 */
app.get("/api/v1/admin/dois", async (req, res) => {
  try {
    const skip = Math.max(0, Number(req.query.skip) || 0);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 10));

    let dois = [];
    let total = 0;

    if (pgPool) {
      try {
        // 查询总数
        const countResult = await pgPool.query("SELECT COUNT(*) as total FROM doi_records");
        total = parseInt(countResult.rows[0].total) || 0;

        // 查询数据
        const result = await pgPool.query(
          "SELECT id, doi, title, authors, journal, year, url FROM doi_records ORDER BY year DESC NULLS LAST LIMIT $1 OFFSET $2",
          [limit, skip]
        );
        dois = result.rows;
      } catch (pgErr) {
        console.error("[admin/dois] PostgreSQL error:", pgErr.message);
      }
    }

    res.json({
      success: true,
      data: {
        dois: dois.map((d) => ({
          id: d.id,
          doi: d.doi,
          title: d.title,
          authors: d.authors,
          journal: d.journal,
          year: d.year,
          url: d.url,
        })),
        total,
      },
    });
  } catch (e) {
    console.error("[admin/dois] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 获取单个DOI详情 */
app.get("/api/v1/admin/dois/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!pgPool) {
      return res.status(500).json({ success: false, message: "PostgreSQL not available" });
    }
    
    const result = await pgPool.query(
      "SELECT * FROM doi_records WHERE id = $1",
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: "DOI not found" });
    }
    
    res.json({
      success: true,
      data: result.rows[0]
    });
  } catch (e) {
    console.error("[admin/dois/:id] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 删除DOI */
app.delete("/api/v1/admin/dois/:id", async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!pgPool) {
      return res.status(500).json({ success: false, message: "PostgreSQL not available" });
    }
    
    await pgPool.query("DELETE FROM doi_records WHERE id = $1", [id]);
    
    res.json({
      success: true,
      message: "DOI deleted successfully"
    });
  } catch (e) {
    console.error("[admin/dois/:id delete] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 搜索日志 */
app.get("/api/v1/admin/logs/searches", async (req, res) => {
  try {
    const skip = Math.max(0, Number(req.query.skip) || 0);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));

    const db = await getSqliteDb();
    const logs = await db.all(
      "SELECT query, result_count, ts FROM query_log ORDER BY ts DESC LIMIT ? OFFSET ?",
      [limit, skip]
    );

    res.json({
      success: true,
      data: {
        logs: logs.map((l) => ({
          query: l.query,
          results_count: l.result_count,
          created_at: l.ts,
          username: "匿名",
        })),
      },
    });
  } catch (e) {
    console.error("[admin/logs/searches] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 客户端错误日志上报 */
app.post("/api/v1/client/log", async (req, res) => {
  try {
    const { level, message, stack, userAgent, url, timestamp } = req.body;
    
    console.error(`[Client Error] ${level}: ${message}`, {
      stack,
      userAgent,
      url,
      timestamp,
      ip: req.ip
    });
    
    // 保存到SQLite
    const db = await getSqliteDb();
    await db.run(
      "INSERT INTO client_logs (level, message, stack, user_agent, url, timestamp, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [level, message, stack, userAgent, url, timestamp, Date.now()]
    );
    
    res.json({ success: true });
  } catch (e) {
    console.error("[client/log] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 获取客户端错误日志 */
app.get("/api/v1/admin/logs/client", async (req, res) => {
  try {
    const skip = Math.max(0, Number(req.query.skip) || 0);
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
    
    const db = await getSqliteDb();
    const logs = await db.all(
      "SELECT * FROM client_logs ORDER BY created_at DESC LIMIT ? OFFSET ?",
      [limit, skip]
    );
    
    res.json({
      success: true,
      data: {
        logs: logs.map(l => ({
          id: l.id,
          level: l.level,
          message: l.message,
          stack: l.stack,
          user_agent: l.user_agent,
          url: l.url,
          timestamp: l.timestamp,
          created_at: l.created_at
        }))
      }
    });
  } catch (e) {
    console.error("[admin/logs/client] error:", e);
    res.status(500).json({ success: false, message: e.message });
  }
});

/** 系统配置 */
app.get("/api/v1/admin/config", async (_req, res) => {
  try {
    // 检查数据库连接状态
    let pgConnected = false;
    let sqliteConnected = false;
    let doiCount = 0;
    let journalCount = 0;
    
    // 检查PostgreSQL
    if (pgPool) {
      try {
        const pgResult = await pgPool.query("SELECT 1");
        pgConnected = true;
        
        // 获取DOI记录数
        const doiResult = await pgPool.query("SELECT COUNT(*) as count FROM doi_records");
        doiCount = parseInt(doiResult.rows[0].count) || 0;
        
        // 获取期刊论文数（从journal_papers表或其他相关表）
        try {
          const journalResult = await pgPool.query("SELECT COUNT(*) as count FROM journal_papers");
          journalCount = parseInt(journalResult.rows[0].count) || 0;
        } catch (e) {
          // 如果表不存在，尝试其他表
          const totalResult = await pgPool.query(`
            SELECT SUM(count) as total FROM (
              SELECT COUNT(*) as count FROM chemistry_catalyst
              UNION ALL
              SELECT COUNT(*) as count FROM materials_science
              UNION ALL
              SELECT COUNT(*) as count FROM physics_optics
              UNION ALL
              SELECT COUNT(*) as count FROM nano_materials
              UNION ALL
              SELECT COUNT(*) as count FROM top_journals
              UNION ALL
              SELECT COUNT(*) as count FROM energy_electrochem
              UNION ALL
              SELECT COUNT(*) as count FROM computational_theory
              UNION ALL
              SELECT COUNT(*) as count FROM metals_alloys
              UNION ALL
              SELECT COUNT(*) as count FROM ceramics_inorganic
            ) as counts
          `);
          journalCount = parseInt(totalResult.rows[0].total) || 0;
        }
      } catch (e) {
        console.error("[admin/config] PostgreSQL check failed:", e.message);
      }
    }
    
    // 检查SQLite
    try {
      const sqliteDb = await getSqliteDb();
      await sqliteDb.get("SELECT 1");
      sqliteConnected = true;
    } catch (e) {
      console.error("[admin/config] SQLite check failed:", e.message);
    }
    
    res.json({
      success: true,
      data: {
        app_name: "QuantumPinnacle（量子巅）",
        app_version: "1.0.0",
        debug: false,
        environment: process.env.NODE_ENV || "development",
        start_time: process.hrtime.bigint().toString(),
        db: {
          postgres: pgConnected,
          sqlite: sqliteConnected,
          doi_count: doiCount,
          journal_count: journalCount
        },
        search: {
          gstack: process.env.ENABLE_GSTACK !== "false",
          gbrain: process.env.ENABLE_GBRAIN !== "false",
          default_channel: "database",
          max_results: 80
        },
        security: {
          jwt: true,
          token_expiry: "24h",
          password_hash: "bcrypt",
          rate_limit: false
        }
      },
    });
  } catch (e) {
    console.error("[admin/config] error:", e);
    res.status(500).json({ 
      success: false, 
      message: e.message,
      data: {
        app_name: "QuantumPinnacle（量子巅）",
        app_version: "1.0.0",
        debug: false,
        db: { postgres: false, sqlite: false, doi_count: 0, journal_count: 0 }
      }
    });
  }
});

// ==================== 启动服务 ====================

await initDatabase().catch((e) => {
  console.error("[db] fatal init", e);
  process.exit(1);
});

await seedDevAdminIfEnabled();

if (String(process.env.SIMPLE_SEED ?? "").trim() === "1") {
  await seedSimplePapersFromJson();
} else {
  console.log(
    "[seed] 已跳过（未设置 SIMPLE_SEED=1）。自建数据：配置 DATABASE_URL 使用 PostgreSQL，或使用默认 SQLite 自行写入 papers 表。",
  );
}

const server = app.listen(PORT, () => {
  console.log(`QuantumPinnacle API: http://127.0.0.1:${PORT}  (POST /api/v1/search)`);
  console.log(`[GStack] 图融合API: POST /api/v1/gstack/fuse`);
  console.log(`[GBrain] 知识图谱API: GET /api/v1/gbrain/profile`);
});
server.setTimeout(920_000);
server.on("error", (err) => {
  if (err && err.code === "EADDRINUSE") {
    console.error(
      `[api] 端口 ${PORT} 已被占用。若此处启动失败而另一旧进程仍在监听，浏览器会连到旧版 API，登录/注册会 404。请先结束占用该端口的进程后再启动（任务管理器结束 node，或换终端执行 netstat -ano | findstr :8787 查 PID）。`,
    );
  } else {
    console.error("[api] listen error", err);
  }
  process.exit(1);
});
