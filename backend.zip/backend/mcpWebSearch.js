/**
 * 可选：通过 MCP（stdio 子进程）拉取网页搜索结果，并入「网页」渠道。
 *
 * 环境变量（均在服务端，勿提交密钥）：
 * - MCP_WEB_COMMAND：可执行文件，如 npx（Windows 上常为 npx.cmd）
 * - MCP_WEB_ARGS_JSON：参数 JSON 数组，如 ["-y","@modelcontextprotocol/server-brave-search"]
 * - MCP_WEB_TOOL：工具名；留空则优先匹配包含 "search" 或 "brave" 的工具名
 * - MCP_WEB_QUERY_ARG：传给工具的查询字段名，默认 query
 * - MCP_WEB_TOOL_ARGS_JSON：与查询合并的额外 JSON 对象（如 {"count":5}）
 * - MCP_WEB_MAX_RESULTS：条数上限，默认 8
 * - MCP_WEB_TIMEOUT_MS：整次 MCP 调用超时，默认 60000（首次 npx -y 拉包可能较慢，可设 90000+）
 * - MCP_WEB_ATTEMPTS：连接/调用失败时的重试次数（含瞬断 -32000），默认 3，范围 1～5
 * - MCP_WEB_ENV_JSON：合并进子进程 env 的 JSON（也可用系统环境变量如 BRAVE_API_KEY）
 *
 * 排错：Brave 官方包须有效 BRAVE_API_KEY；Windows 用 npx.cmd；看运行 npm run dev:server 的终端里子进程 stderr。
 *
 * 备用方案：未配置 MCP/Brave 时自动退回 DuckDuckGo Lite 免费网页搜索。
 */

import crypto from "node:crypto";
import { Client } from "@modelcontextprotocol/sdk/client";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { extractDoiCandidate } from "./doi.js";
import { extractPatentNumberFromPaper } from "./patentNumber.js";

/** @returns {null | { command: string, args: string[], env: Record<string,string>, toolHint: string, queryArg: string, maxResults: number, timeoutMs: number, connectAttempts: number, toolExtra: Record<string, unknown> }} */
export function getMcpWebSearchConfig() {
  const command = String(process.env.MCP_WEB_COMMAND ?? "").trim();
  if (!command) return null;

  let args = [];
  try {
    const raw = String(process.env.MCP_WEB_ARGS_JSON ?? "[]").trim();
    const j = JSON.parse(raw);
    if (Array.isArray(j)) args = j.map(String);
  } catch {
    args = [];
  }

  let extraEnv = {};
  try {
    const er = String(process.env.MCP_WEB_ENV_JSON ?? "").trim();
    if (er) {
      const o = JSON.parse(er);
      if (o && typeof o === "object" && !Array.isArray(o)) {
        for (const [k, v] of Object.entries(o)) {
          if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") {
            extraEnv[String(k)] = String(v);
          }
        }
      }
    }
  } catch {
    /* ignore */
  }

  let toolExtra = {};
  try {
    const tr = String(process.env.MCP_WEB_TOOL_ARGS_JSON ?? "").trim();
    if (tr) {
      const o = JSON.parse(tr);
      if (o && typeof o === "object" && !Array.isArray(o)) toolExtra = o;
    }
  } catch {
    toolExtra = {};
  }

  const toolHint = String(process.env.MCP_WEB_TOOL ?? "").trim();
  const queryArg = String(process.env.MCP_WEB_QUERY_ARG ?? "query").trim() || "query";
  const maxResults = Math.min(35, Math.max(1, Number(process.env.MCP_WEB_MAX_RESULTS) || 8));
  const timeoutMs = Math.min(120_000, Math.max(5000, Number(process.env.MCP_WEB_TIMEOUT_MS) || 60_000));
  const connectAttempts = Math.min(
    5,
    Math.max(1, (() => {
      const n = Number(process.env.MCP_WEB_ATTEMPTS);
      return Number.isFinite(n) && n >= 1 ? Math.floor(n) : 3;
    })()),
  );

  return {
    command,
    args,
    env: { ...process.env, ...extraEnv },
    toolHint,
    queryArg,
    maxResults,
    timeoutMs,
    connectAttempts,
    toolExtra,
  };
}

function stableWebId(url) {
  return crypto.createHash("sha256").update(url).digest("hex").slice(0, 22);
}

/** @param {unknown} obj @param {Array<{url:string,title:string,description:string}>} out */
function collectUrlResults(obj, out, depth) {
  if (depth > 14 || obj == null) return;
  if (Array.isArray(obj)) {
    for (const x of obj) collectUrlResults(x, out, depth + 1);
    return;
  }
  if (typeof obj !== "object") return;
  const o = /** @type {Record<string, unknown>} */ (obj);
  const url = o.url ?? o.URL ?? o.href ?? o.link ?? o.uri;
  const title = o.title ?? o.name ?? o.heading ?? "";
  const desc = o.description ?? o.snippet ?? o.body ?? o.summary ?? o.text ?? "";
  if (typeof url === "string" && /^https?:\/\//i.test(url)) {
    out.push({
      url: url.split("#")[0],
      title: String(title || "Web").slice(0, 400),
      description: String(desc).slice(0, 1200),
    });
  }
  for (const k of Object.keys(o)) collectUrlResults(o[k], out, depth + 1);
}

/** @param {unknown} result */
function papersFromToolResult(result, max) {
  const rawItems = [];
  if (!result || typeof result !== "object") return [];
  const sc = /** @type {{ structuredContent?: unknown }} */ (result).structuredContent;
  if (sc && typeof sc === "object") collectUrlResults(sc, rawItems, 0);

  const texts = [];
  for (const c of result?.content ?? []) {
    if (c?.type === "text" && typeof c.text === "string") texts.push(c.text);
  }
  const joined = texts.join("\n");
  if (joined) {
    try {
      const j = JSON.parse(joined);
      collectUrlResults(j, rawItems, 0);
    } catch {
      try {
        const re = /\[[^\]]*\]\((https?:\/\/[^)\s]+)\)/g;
        let m;
        while ((m = re.exec(joined))) {
          rawItems.push({ url: m[1], title: "Link", description: joined.slice(0, 400) });
        }
      } catch {
        /* ignore */
      }
    }
  }

  const seen = new Set();
  const papers = [];
  for (const it of rawItems) {
    const u = String(it.url || "").trim();
    if (!u || seen.has(u)) continue;
    seen.add(u);
    const doi = extractDoiCandidate(`${u} ${it.description}`) || extractDoiCandidate(it.title);
    const id = stableWebId(u);
    const summary = it.description || it.title;
    papers.push({
      paper_id: `mcpweb:${id}`,
      doi,
      title: it.title || u,
      abstract: summary,
      year: null,
      venue: "Web (MCP)",
      oa_status: null,
      authors_json: JSON.stringify([]),
      authors: [],
      summary,
      published: "",
      id,
      absUrl: u,
      pdfUrl: u,
      source: "mcp_web",
      isReferencedByCount: null,
    });
    if (papers.length >= max) break;
  }
  return papers;
}

/** @param {{ name: string }[]} tools @param {string} hint */
function pickToolName(tools, hint) {
  if (!tools?.length) return null;
  if (hint) {
    const exact = tools.find((t) => t.name === hint);
    if (exact) return exact.name;
    const partial = tools.find((t) => t.name.includes(hint));
    if (partial) return partial.name;
  }
  const bySearch = tools.find((t) => /search/i.test(t.name));
  if (bySearch) return bySearch.name;
  const brave = tools.find((t) => /brave/i.test(t.name));
  if (brave) return brave.name;
  return tools[0]?.name ?? null;
}

/**
 * @param {string} query
 * @param {number} max
 * @returns {Promise<{ papers: object[]; note: string; toolName?: string }>}
 */
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/** MCP 子进程偶发 JSON-RPC Connection closed（-32000），重连常可恢复 */
function isMcpTransientDisconnect(err) {
  const s = `${err?.message || err?.code || err || ""}`;
  return /connection closed|-32000|ECONNRESET|EPIPE|socket hang up/i.test(s);
}

/** Brave Search 官方 MCP 包需要 BRAVE_API_KEY */
function argsLookLikeBraveSearch(args) {
  const j = args.join("\0").toLowerCase();
  return j.includes("server-brave-search") || j.includes("brave-search");
}

function braveApiKeyPresent(env) {
  const k = env?.BRAVE_API_KEY ?? process.env.BRAVE_API_KEY;
  return typeof k === "string" && k.trim().length > 0;
}

export function isMcpUsable() {
  var cfg = getMcpWebSearchConfig();
  if (!cfg) return false;
  if (argsLookLikeBraveSearch(cfg.args) && !braveApiKeyPresent(cfg.env)) return false;
  return true;
}

export async function fetchMcpWebPapers(query, max) {
  const cfg = getMcpWebSearchConfig();
  if (!cfg) return { papers: [], note: "disabled" };

  const q = String(query ?? "").trim();
  if (!q) return { papers: [], note: "empty-query" };

  if (argsLookLikeBraveSearch(cfg.args) && !braveApiKeyPresent(cfg.env)) {
    /** 与未配置 MCP 一致：静默跳过，避免在「数据源」里刷 Brave 提示 */
    return { papers: [], note: "disabled" };
  }

  const maxAttempts = cfg.connectAttempts;
  let lastNote = "err:unknown";

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const transport = new StdioClientTransport({
      command: cfg.command,
      args: cfg.args,
      env: cfg.env,
    });
    const client = new Client({ name: "quantum-pinnacle", version: "1.0.0" }, { capabilities: {} });

    const run = async () => {
      await client.connect(transport);
      const listed = await client.listTools();
      const tools = listed?.tools ?? [];
      const toolName = pickToolName(tools, cfg.toolHint);
      if (!toolName) {
        return { papers: [], note: "no-tools", toolName: null };
      }
      const args = {
        ...cfg.toolExtra,
        [cfg.queryArg]: q.slice(0, 2000),
      };
      if (cfg.toolExtra.count == null && cfg.toolExtra.limit == null) {
        args.count = Math.min(max, cfg.maxResults);
      }
      const result = await client.callTool({
        name: toolName,
        arguments: args,
      });
      if (result?.isError) {
        const msg = result.content?.map((c) => (c.type === "text" ? c.text : "")).join(" | ");
        return { papers: [], note: `tool-error:${(msg || "unknown").slice(0, 120)}`, toolName };
      }
      const papers = papersFromToolResult(result, Math.min(max, cfg.maxResults));
      return { papers, note: papers.length ? "ok" : "no-url-results", toolName };
    };

    let timeoutId;
    const timeout = new Promise((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error("mcp_timeout")), cfg.timeoutMs);
    });

    try {
      const out = await Promise.race([run(), timeout]);
      clearTimeout(timeoutId);
      await client.close().catch(() => {});
      return out;
    } catch (e) {
      clearTimeout(timeoutId);
      await client.close().catch(() => {});
      const msg = e?.message || String(e);
      lastNote = msg.includes("mcp_timeout") ? "timeout" : `err:${msg.slice(0, 120)}`;
      if (attempt < maxAttempts - 1 && isMcpTransientDisconnect(e)) {
        const backoff = 700 + attempt * 550;
        console.warn(`[mcp_web] transient disconnect (attempt ${attempt + 1}/${maxAttempts}), retry in ${backoff}ms`, msg);
        await sleep(backoff);
        continue;
      }
      return { papers: [], note: lastNote };
    }
  }

  return { papers: [], note: lastNote };
}

var _ddgUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

const DDG_URLS = [
  "https://lite.duckduckgo.com/lite/",
  "https://html.duckduckgo.com/html/",
];

function _ddgFetchOne(url, query, timeoutMs) {
  const fullUrl = url + "?q=" + encodeURIComponent(query);
  var ua = typeof process !== "undefined" ? String(process.env?.DDG_USER_AGENT || _ddgUA || "Mozilla/5.0").trim() : _ddgUA;
  if (!ua) ua = "Mozilla/5.0 (compatible; QuantumPinnacle/1.0)";
  var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  var timer = controller ? setTimeout(function () { controller.abort(); }, timeoutMs || 8000) : null;
  var opts = { headers: { "User-Agent": ua, Accept: "text/html,application/xhtml+xml" } };
  if (controller) opts.signal = controller.signal;
  return fetch(fullUrl, opts).then(function (r) {
    if (timer) clearTimeout(timer);
    if (!r.ok) throw new Error("DDG HTTP " + r.status);
    return r.text();
  });
}

function _ddgFetch(query) {
  return DDG_URLS.reduce(function (chain, url) {
    return chain.catch(function () {
      return _ddgFetchOne(url, query, 8000);
    });
  }, Promise.reject(new Error("no-dd-endpoints")));
}

function _ddgParseResults(html, max) {
  var results = [];
  var re = /<a[^>]*\srel\s*=\s*["']?\w*\s*nofollow\w*["']?[^>]*\sclass\s*=\s*["'](?:result-link|result-snippet)["']?[^>]*\shref\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  var match;
  while ((match = re.exec(html)) !== null) {
    var url = match[1];
    var text = match[2].replace(/<[^>]+>/g, "").trim();
    if (!url || !/^https?:\/\//i.test(url)) continue;
    if (results.length >= max) break;
    var isNew = !results.some(function (r) { return r.url === url; });
    if (isNew) {
      results.push({ url: url, title: text || url, description: "" });
    }
  }
  var snipRe = /<td[^>]*class\s*=\s*["']?(?:result-snippet)?["']?[^>]*>([\s\S]*?)<\/td>/gi;
  var idx = 0;
  while ((match = snipRe.exec(html)) !== null && idx < max) {
    var snippet = match[1].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    if (snippet && idx < results.length) {
      results[idx].description = snippet.slice(0, 600);
    }
    idx++;
  }
  if (results.length === 0) {
    var altRe = /<a[^>]*\shref\s*=\s*["'](\/\/duckduckgo\.com\/l\/\?uddg=[^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    while ((match = altRe.exec(html)) !== null) {
      var raw = match[1];
      try {
        var params = new URL(raw, "https://lite.duckduckgo.com").searchParams;
        var realUrl = params.get("uddg") || raw;
      } catch (e) {
        realUrl = raw;
      }
      var decoded = "";
      try { decoded = decodeURIComponent(realUrl); } catch (e) { decoded = realUrl; }
      if (!/^https?:\/\//i.test(decoded)) continue;
      var title = match[2].replace(/<[^>]+>/g, "").trim();
      results.push({ url: decoded, title: title || decoded, description: "" });
      if (results.length >= max) break;
    }
  }
  return results.slice(0, max);
}

function _ddgToPapers(items, sourceLabel) {
  var seen = new Set();
  var papers = [];
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    var u = String(it.url || "").trim();
    if (!u || seen.has(u)) continue;
    seen.add(u);
    var desc = String(it.description || "");
    var title = String(it.title || "").slice(0, 400) || u;
    var doi =
      sourceLabel === "ddg_patent"
        ? null
        : extractDoiCandidate(u + " " + desc) || extractDoiCandidate(title);
    var id = stableWebId(u);
    var row = {
      paper_id: sourceLabel + ":" + id,
      doi: doi,
      title: title,
      abstract: desc.slice(0, 1200),
      year: null,
      venue: sourceLabel === "ddg_patent" ? "Patent (Web)" : "Web (DDG)",
      oa_status: null,
      authors_json: JSON.stringify([]),
      authors: [],
      summary: String(desc || title || "").slice(0, 800),
      published: "",
      id: id,
      absUrl: u,
      pdfUrl: u,
      source: sourceLabel,
      isReferencedByCount: null,
    };
    if (sourceLabel === "ddg_patent") {
      var pn = extractPatentNumberFromPaper(row);
      if (pn) row.patentNumber = pn;
    }
    papers.push(row);
    if (papers.length >= 20) break;
  }
  return papers;
}

/**
 * @param {string} query
 * @param {number} max
 * @param {{ forPatent?: boolean }} [opts] forPatent 为 true 时标记为 ddg_patent（专利补充检索）
 */
export async function fetchDuckDuckGoSearch(query, max, opts) {
  const forPatent = Boolean(opts && opts.forPatent);
  const sourceLabel = forPatent ? "ddg_patent" : "ddg_web";
  const toolSuffix = forPatent ? "duckduckgo-patent" : "duckduckgo-lite";
  var q = String(query || "").trim();
  if (!q) return { papers: [], note: "empty-query" };
  try {
    var html = await _ddgFetch(q);
    var items = _ddgParseResults(html, Math.min(max || 10, 20));
    if (!items.length) {
      var bingItems = await _bingFallback(q, Math.min(max || 10, 20));
      if (bingItems.length) {
        return { papers: _ddgToPapers(bingItems, sourceLabel), note: "bing_fallback", toolName: `bing-fallback${forPatent ? "-patent" : ""}` };
      }
      return { papers: [], note: "no-dd-results" };
    }
    var papers = _ddgToPapers(items, sourceLabel);
    return { papers: papers, note: "ddg_ok", toolName: toolSuffix };
  } catch (e) {
    console.warn("[ddg_web] DuckDuckGo fetch failed:", e?.message);
    try {
      var bFallback = await _bingFallback(q, Math.min(max || 10, 20));
      if (bFallback.length) {
        return { papers: _ddgToPapers(bFallback, sourceLabel), note: "bing_fallback_after_ddg_err", toolName: `bing-fallback${forPatent ? "-patent" : ""}` };
      }
    } catch (e2) {
      console.warn("[ddg_web] Bing fallback also failed:", e2?.message);
    }
    return { papers: [], note: "ddg_err:" + String(e?.message || "unknown").slice(0, 100) };
  }
}

async function _bingFallback(query, max) {
  try {
    const url = "https://www.bing.com/search?q=" + encodeURIComponent(query) + "&count=" + max;
    var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, 8000) : null;
    var opts = {
      headers: {
        "User-Agent": _ddgUA,
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "en-US,en;q=0.9",
      },
    };
    if (controller) opts.signal = controller.signal;
    const res = await fetch(url, opts);
    if (timer) clearTimeout(timer);
    if (!res.ok) return [];
    const html = await res.text();
    
    var results = [];
    if (/<li class="b_algo">/i.test(html) || /<ol id="b_results">/i.test(html)) {
      var citeRe = /<cite[^>]*>([\s\S]*?)<\/cite>/gi;
      var titleRe = /<h2[^>]*>[\s\S]*?<a[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/gi;
      var descRe = /<p[^>]*class="[^"]*b_lineclamp[^"]*"[^>]*>([\s\S]*?)<\/p>/gi;
      
      var match;
      while ((match = titleRe.exec(html)) !== null && results.length < max) {
        var href = match[1];
        var title = match[2].replace(/<[^>]+>/g, "").trim();
        if (href && /^https?:\/\//i.test(href)) {
          results.push({ url: href, title: title || href, description: "" });
        }
      }
      
      var descIdx = 0;
      while ((match = descRe.exec(html)) !== null && descIdx < results.length) {
        results[descIdx].description = match[1].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 600);
        descIdx++;
      }
    }
    return results;
  } catch (e) {
    console.warn("[bing_fallback]", e?.message);
    return [];
  }
}

export async function fetchPatentPapers(query, max) {
  var cfg = getMcpWebSearchConfig();
  if (cfg) {
    var braveCheck = argsLookLikeBraveSearch(cfg.args) && !braveApiKeyPresent(cfg.env);
    if (braveCheck) {
      return await fetchDuckDuckGoSearch(String(query || "").trim() + " patent", max, { forPatent: true });
    }
    const out = await fetchMcpWebPapers(String(query || "").trim() + " patent", max);
    const papers = (out.papers ?? []).map(function (p) {
      const row = {
        ...p,
        source: "ddg_patent",
        venue: "Patent (Web)",
      };
      const pn = extractPatentNumberFromPaper(row);
      if (pn) row.patentNumber = pn;
      return row;
    });
    return { papers: papers, note: out.note, toolName: out.toolName };
  }
  return await fetchDuckDuckGoSearch(String(query || "").trim() + " patent", max, { forPatent: true });
}
